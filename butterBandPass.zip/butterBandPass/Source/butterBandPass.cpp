//
// butterBandPass.cpp
//
// Code generation for function 'butterBandPass'
//

// Include files
#include "butterBandPass.h"
#include "butterBandPass_types.h"
#include "rt_nonfinite.h"
#include "coder_array.h"
#include "rt_defines.h"
#include <algorithm>
#include <cfloat>
#include <cmath>
#include <cstring>

// Function Declarations
namespace coder {
static void b_rand(butterBandPassStackData *SD, const double varargin_1[2],
                   ::coder::array<double, 2U> &r);

static void b_sqrt(creal_T *x);

static void bilinear(const ::coder::array<double, 2U> &z, const double p_data[],
                     int p_size, const double k_data[], const int k_size[2],
                     double fs, ::coder::array<double, 2U> &zd,
                     double pd_data[], int *pd_size, double kd_data[],
                     int kd_size[2], double *dd);

static void buttap(double n, creal_T p_data[], int *p_size, double *k);

static void butter(double n, const double Wn[2], double varargout_1_data[],
                   int varargout_1_size[2], double varargout_2_data[],
                   int varargout_2_size[2]);

static void buttzeros(double n, double Wn, const creal_T p_data[], int p_size,
                      creal_T z_data[], int *z_size, double *k);

static void eig(const ::coder::array<double, 2U> &A, creal_T V_data[],
                int *V_size);

static void eigHermitianStandard(const ::coder::array<double, 2U> &A,
                                 double V_data[], int *V_size);

namespace internal {
static void b_lusolve(const ::coder::array<double, 2U> &A, double B_data[],
                      const int B_size[2]);

namespace blas {
static void xgerc(int m, int n, double alpha1, int ix0, const double y_data[],
                  ::coder::array<double, 2U> &A, int ia0, int lda);

static double xnrm2(int n, const double x[3]);

static double xnrm2(int n, const ::coder::array<double, 2U> &x, int ix0);

} // namespace blas
static boolean_T cplxpairv(creal_T x_data[], const int *x_size, double tol);

namespace lapack {
static void xgehrd(::coder::array<double, 2U> &a);

static void xgeqp3(::coder::array<double, 2U> &A, double tau_data[],
                   int *tau_size, int jpvt_data[], int jpvt_size[2]);

static void xgetrf(int m, int n, ::coder::array<double, 2U> &A, int lda,
                   int ipiv_data[], int ipiv_size[2], int *info);

} // namespace lapack
static void lusolve(const ::coder::array<double, 2U> &A, double B_data[],
                    const int *B_size);

static void lusolve(const ::coder::array<double, 2U> &A,
                    const ::coder::array<double, 2U> &B,
                    ::coder::array<double, 2U> &X);

static void mrdiv(const double A_data[], const int A_size[2],
                  const ::coder::array<double, 2U> &B, double Y_data[],
                  int Y_size[2]);

static void qrsolve(const ::coder::array<double, 2U> &A, const double B_data[],
                    int B_size, double Y_data[], int *Y_size);

static void qrsolve(const ::coder::array<double, 2U> &A,
                    const ::coder::array<double, 2U> &B,
                    ::coder::array<double, 2U> &Y);

static int rankFromQR(const ::coder::array<double, 2U> &A);

namespace reflapack {
static int eml_dlahqr(::coder::array<double, 2U> &h);

static void qrpf(::coder::array<double, 2U> &A, int m, int n, double tau_data[],
                 int jpvt_data[]);

static void xdlanv2(double *a, double *b, double *c, double *d, double *rt1r,
                    double *rt1i, double *rt2r, double *rt2i, double *cs,
                    double *sn);

static void xzgeev(const ::coder::array<double, 2U> &A, int *info,
                   creal_T alpha1_data[], int *alpha1_size,
                   creal_T beta1_data[], int *beta1_size);

static void xzggbal(::coder::array<creal_T, 2U> &A, int *ilo, int *ihi,
                    int rscale_data[], int *rscale_size);

static void xzhgeqz(const ::coder::array<creal_T, 2U> &A, int ilo, int ihi,
                    int *info, creal_T alpha1_data[], int *alpha1_size,
                    creal_T beta1_data[], int *beta1_size);

static double xzlarfg(int n, double *alpha1, ::coder::array<double, 2U> &x,
                      int ix0);

static void xzlartg(const creal_T f, const creal_T g, double *cs, creal_T *sn);

static void xzlartg(const creal_T f, const creal_T g, double *cs, creal_T *sn,
                    creal_T *r);

} // namespace reflapack
} // namespace internal
static void lp2bp(const ::coder::array<double, 2U> &a, const double b_data[],
                  int b_size, const double c_data[], const int c_size[2],
                  double d, double wo, double bw,
                  ::coder::array<double, 2U> &at, double bt_data[],
                  int *bt_size, double ct_data[], int ct_size[2], double *dt);

static void mldivide(const ::coder::array<double, 2U> &A, const double B_data[],
                     int B_size, double Y_data[], int *Y_size);

static void mldivide(const ::coder::array<double, 2U> &A,
                     const ::coder::array<double, 2U> &B,
                     ::coder::array<double, 2U> &Y);

static void zp2ss(const creal_T p_data[], int p_size, double k,
                  ::coder::array<double, 2U> &a, double b_data[], int *b_size,
                  double c_data[], int c_size[2], double *d);

} // namespace coder
static void eml_rand_mt19937ar_stateful_init(butterBandPassStackData *SD);

static derivedAudioPlugin *getPluginInstance(butterBandPassStackData *SD);

static void getPluginInstance_init(butterBandPassStackData *SD);

static double rt_atan2d_snf(double u0, double u1);

static double rt_hypotd_snf(double u0, double u1);

static double rt_remd_snf(double u0, double u1);

// Function Definitions
namespace coder {
static void b_rand(butterBandPassStackData *SD, const double varargin_1[2],
                   ::coder::array<double, 2U> &r)
{
  unsigned int u[2];
  int i;
  r.set_size(static_cast<int>(varargin_1[0]), 2);
  i = static_cast<int>(varargin_1[0]) << 1;
  for (int k{0}; k < i; k++) {
    double b_r;
    // ========================= COPYRIGHT NOTICE ============================
    //  This is a uniform (0,1) pseudorandom number generator based on:
    //
    //  A C-program for MT19937, with initialization improved 2002/1/26.
    //  Coded by Takuji Nishimura and Makoto Matsumoto.
    //
    //  Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,
    //  All rights reserved.
    //
    //  Redistribution and use in source and binary forms, with or without
    //  modification, are permitted provided that the following conditions
    //  are met:
    //
    //    1. Redistributions of source code must retain the above copyright
    //       notice, this list of conditions and the following disclaimer.
    //
    //    2. Redistributions in binary form must reproduce the above copyright
    //       notice, this list of conditions and the following disclaimer
    //       in the documentation and/or other materials provided with the
    //       distribution.
    //
    //    3. The names of its contributors may not be used to endorse or
    //       promote products derived from this software without specific
    //       prior written permission.
    //
    //  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
    //  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
    //  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
    //  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT
    //  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
    //  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
    //  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
    //  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
    //  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
    //  (INCLUDING  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
    //  OF THIS  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
    //
    // =============================   END   =================================
    do {
      for (int j{0}; j < 2; j++) {
        unsigned int mti;
        unsigned int y;
        mti = SD->pd->state[624] + 1U;
        if (SD->pd->state[624] + 1U >= 625U) {
          int kk;
          for (kk = 0; kk < 227; kk++) {
            y = (SD->pd->state[kk] & 2147483648U) |
                (SD->pd->state[kk + 1] & 2147483647U);
            if ((y & 1U) == 0U) {
              y >>= 1U;
            } else {
              y = y >> 1U ^ 2567483615U;
            }
            SD->pd->state[kk] = SD->pd->state[kk + 397] ^ y;
          }
          for (kk = 0; kk < 396; kk++) {
            y = (SD->pd->state[kk + 227] & 2147483648U) |
                (SD->pd->state[kk + 228] & 2147483647U);
            if ((y & 1U) == 0U) {
              y >>= 1U;
            } else {
              y = y >> 1U ^ 2567483615U;
            }
            SD->pd->state[kk + 227] = SD->pd->state[kk] ^ y;
          }
          y = (SD->pd->state[623] & 2147483648U) |
              (SD->pd->state[0] & 2147483647U);
          if ((y & 1U) == 0U) {
            y >>= 1U;
          } else {
            y = y >> 1U ^ 2567483615U;
          }
          SD->pd->state[623] = SD->pd->state[396] ^ y;
          mti = 1U;
        }
        y = SD->pd->state[static_cast<int>(mti) - 1];
        SD->pd->state[624] = mti;
        y ^= y >> 11U;
        y ^= y << 7U & 2636928640U;
        y ^= y << 15U & 4022730752U;
        u[j] = y ^ y >> 18U;
      }
      u[0] >>= 5U;
      u[1] >>= 6U;
      b_r = 1.1102230246251565E-16 * (static_cast<double>(u[0]) * 6.7108864E+7 +
                                      static_cast<double>(u[1]));
    } while (b_r == 0.0);
    r[k] = b_r;
  }
}

static void b_sqrt(creal_T *x)
{
  double absxi;
  double xi;
  double xr;
  xr = x->re;
  xi = x->im;
  if (xi == 0.0) {
    if (xr < 0.0) {
      absxi = 0.0;
      xr = std::sqrt(-xr);
    } else {
      absxi = std::sqrt(xr);
      xr = 0.0;
    }
  } else if (xr == 0.0) {
    if (xi < 0.0) {
      absxi = std::sqrt(-xi / 2.0);
      xr = -absxi;
    } else {
      absxi = std::sqrt(xi / 2.0);
      xr = absxi;
    }
  } else if (std::isnan(xr)) {
    absxi = xr;
  } else if (std::isnan(xi)) {
    absxi = xi;
    xr = xi;
  } else if (std::isinf(xi)) {
    absxi = std::abs(xi);
    xr = xi;
  } else if (std::isinf(xr)) {
    if (xr < 0.0) {
      absxi = 0.0;
      xr = xi * -xr;
    } else {
      absxi = xr;
      xr = 0.0;
    }
  } else {
    double absxr;
    absxr = std::abs(xr);
    absxi = std::abs(xi);
    if ((absxr > 4.4942328371557893E+307) ||
        (absxi > 4.4942328371557893E+307)) {
      absxr *= 0.5;
      absxi = rt_hypotd_snf(absxr, absxi * 0.5);
      if (absxi > absxr) {
        absxi = std::sqrt(absxi) * std::sqrt(absxr / absxi + 1.0);
      } else {
        absxi = std::sqrt(absxi) * 1.4142135623730951;
      }
    } else {
      absxi = std::sqrt((rt_hypotd_snf(absxr, absxi) + absxr) * 0.5);
    }
    if (xr > 0.0) {
      xr = 0.5 * (xi / absxi);
    } else {
      if (xi < 0.0) {
        xr = -absxi;
      } else {
        xr = absxi;
      }
      absxi = 0.5 * (xi / xr);
    }
  }
  x->re = absxi;
  x->im = xr;
}

static void bilinear(const ::coder::array<double, 2U> &z, const double p_data[],
                     int p_size, const double k_data[], const int k_size[2],
                     double fs, ::coder::array<double, 2U> &zd,
                     double pd_data[], int *pd_size, double kd_data[],
                     int kd_size[2], double *dd)
{
  array<double, 2U> c_I;
  array<double, 2U> r;
  array<double, 2U> t2;
  array<signed char, 2U> b_I;
  double tmp_data[1002];
  double b_d;
  int tmp_size[2];
  int d;
  int i;
  int loop_ub;
  r.set_size(z.size(0), z.size(1));
  loop_ub = z.size(0) * z.size(1);
  for (i = 0; i < loop_ub; i++) {
    r[i] = z[i] * 0.5 / 2.0;
  }
  loop_ub = static_cast<short>(z.size(0));
  d = static_cast<short>(z.size(1));
  if (loop_ub < d) {
    d = loop_ub;
  }
  t2.set_size(static_cast<int>(static_cast<short>(z.size(0))),
              static_cast<int>(static_cast<short>(z.size(1))));
  loop_ub = static_cast<short>(z.size(0)) * static_cast<short>(z.size(1));
  for (i = 0; i < loop_ub; i++) {
    t2[i] = 0.0;
  }
  if (d > 0) {
    for (loop_ub = 0; loop_ub < d; loop_ub++) {
      t2[loop_ub + t2.size(0) * loop_ub] = 1.0;
    }
  }
  loop_ub = t2.size(0) * t2.size(1);
  for (i = 0; i < loop_ub; i++) {
    t2[i] = t2[i] - r[i];
  }
  loop_ub = static_cast<short>(z.size(0));
  d = static_cast<short>(z.size(1));
  if (loop_ub < d) {
    d = loop_ub;
  }
  b_I.set_size(static_cast<int>(static_cast<short>(z.size(0))),
               static_cast<int>(static_cast<short>(z.size(1))));
  loop_ub = static_cast<short>(z.size(0)) * static_cast<short>(z.size(1));
  for (i = 0; i < loop_ub; i++) {
    b_I[i] = 0;
  }
  if (d > 0) {
    for (loop_ub = 0; loop_ub < d; loop_ub++) {
      b_I[loop_ub + b_I.size(0) * loop_ub] = 1;
    }
  }
  c_I.set_size(b_I.size(0), b_I.size(1));
  loop_ub = b_I.size(0) * b_I.size(1);
  for (i = 0; i < loop_ub; i++) {
    c_I[i] = static_cast<double>(b_I[i]) + r[i];
  }
  mldivide(t2, c_I, zd);
  mldivide(t2, p_data, p_size, pd_data, pd_size);
  for (i = 0; i < *pd_size; i++) {
    pd_data[i] *= 0.70710678118654746;
  }
  tmp_size[0] = 1;
  tmp_size[1] = k_size[1];
  loop_ub = k_size[1];
  for (i = 0; i < loop_ub; i++) {
    tmp_data[i] = 0.70710678118654757 * k_data[i];
  }
  internal::mrdiv(tmp_data, tmp_size, t2, kd_data, kd_size);
  internal::mrdiv(k_data, k_size, t2, tmp_data, tmp_size);
  b_d = 0.0;
  loop_ub = tmp_size[1];
  for (i = 0; i < loop_ub; i++) {
    b_d += tmp_data[i] * p_data[i];
  }
  *dd = b_d * 0.5 / 2.0 + fs;
}

static void buttap(double n, creal_T p_data[], int *p_size, double *k)
{
  creal_T x_data[1002];
  creal_T ptemp_data[250];
  double y_data[250];
  double d;
  double r;
  int loop_ub;
  int p_tmp;
  int y_size_idx_1;
  if (std::isnan(n - 1.0)) {
    y_size_idx_1 = 1;
    y_data[0] = rtNaN;
  } else if (n - 1.0 < 1.0) {
    y_size_idx_1 = 0;
  } else {
    loop_ub = static_cast<int>(std::floor(((n - 1.0) - 1.0) / 2.0));
    y_size_idx_1 = loop_ub + 1;
    for (p_tmp = 0; p_tmp <= loop_ub; p_tmp++) {
      y_data[p_tmp] = 2.0 * static_cast<double>(p_tmp) + 1.0;
    }
  }
  d = 2.0 * n;
  for (p_tmp = 0; p_tmp < y_size_idx_1; p_tmp++) {
    r = 3.1415926535897931 * y_data[p_tmp] / d + 1.5707963267948966;
    ptemp_data[p_tmp].re = r * 0.0;
    ptemp_data[p_tmp].im = r;
  }
  for (loop_ub = 0; loop_ub < y_size_idx_1; loop_ub++) {
    d = ptemp_data[loop_ub].im;
    if (d == 0.0) {
      ptemp_data[loop_ub].re = std::exp(ptemp_data[loop_ub].re);
      ptemp_data[loop_ub].im = 0.0;
    } else {
      boolean_T guard1{false};
      guard1 = false;
      if (std::isinf(d)) {
        r = ptemp_data[loop_ub].re;
        if (std::isinf(r) && (r < 0.0)) {
          ptemp_data[loop_ub].re = 0.0;
          ptemp_data[loop_ub].im = 0.0;
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }
      if (guard1) {
        r = std::exp(ptemp_data[loop_ub].re / 2.0);
        ptemp_data[loop_ub].re = r * (r * std::cos(d));
        d = r * (r * std::sin(d));
        ptemp_data[loop_ub].im = d;
      }
    }
  }
  if (std::isnan(n) || std::isinf(n)) {
    r = rtNaN;
  } else if (n == 0.0) {
    r = 0.0;
  } else {
    r = std::fmod(n, 2.0);
    if (r == 0.0) {
      r = 0.0;
    } else if (n < 0.0) {
      r += 2.0;
    }
  }
  if (r == 1.0) {
    loop_ub = y_size_idx_1 << 1;
    *p_size = loop_ub + 1;
    p_data[loop_ub].re = -1.0;
    p_data[loop_ub].im = 0.0;
  } else {
    *p_size = y_size_idx_1 << 1;
  }
  for (loop_ub = 0; loop_ub < y_size_idx_1; loop_ub++) {
    p_tmp = ((loop_ub + 1) << 1) - 1;
    p_data[p_tmp - 1] = ptemp_data[loop_ub];
    p_data[p_tmp].re = ptemp_data[loop_ub].re;
    p_data[p_tmp].im = -ptemp_data[loop_ub].im;
  }
  for (p_tmp = 0; p_tmp < *p_size; p_tmp++) {
    x_data[p_tmp].re = -p_data[p_tmp].re;
    x_data[p_tmp].im = -p_data[p_tmp].im;
  }
  if (*p_size == 0) {
    *k = 1.0;
  } else {
    double im;
    *k = x_data[0].re;
    im = x_data[0].im;
    for (loop_ub = 2; loop_ub <= *p_size; loop_ub++) {
      double re;
      d = x_data[loop_ub - 1].re;
      r = x_data[loop_ub - 1].im;
      re = *k * d - im * r;
      im = *k * r + im * d;
      *k = re;
    }
  }
}

static void butter(double n, const double Wn[2], double varargout_1_data[],
                   int varargout_1_size[2], double varargout_2_data[],
                   int varargout_2_size[2])
{
  array<double, 2U> a;
  array<double, 2U> ad;
  array<double, 2U> b_ad;
  creal_T b_c_data[1003];
  creal_T p_data[1002];
  creal_T z_data[1000];
  creal_T ps_data[501];
  double b_bd_data[1002];
  double b_cd_data[1002];
  double bd_data[1002];
  double cd_data[1002];
  double b_data[501];
  double c_data[501];
  double Wn1;
  double d;
  double dd;
  double ks;
  double u_idx_0;
  double u_idx_1;
  int c_size[2];
  int cd_size[2];
  int b_size;
  int bd_size;
  int c_size_idx_1;
  int ps_size;
  int z_size;
  u_idx_0 = 4.0 * std::tan(3.1415926535897931 * Wn[0] / 2.0);
  u_idx_1 = 4.0 * std::tan(3.1415926535897931 * Wn[1] / 2.0);
  buttap(n, ps_data, &ps_size, &ks);
  zp2ss(ps_data, ps_size, ks, a, b_data, &b_size, c_data, c_size, &d);
  Wn1 = std::sqrt(u_idx_0 * u_idx_1);
  lp2bp(a, b_data, b_size, c_data, c_size, d, Wn1, u_idx_1 - u_idx_0, ad,
        bd_data, &ps_size, cd_data, cd_size, &dd);
  bilinear(ad, bd_data, ps_size, cd_data, cd_size, dd, b_ad, b_bd_data,
           &bd_size, b_cd_data, c_size, &ks);
  eig(b_ad, p_data, &bd_size);
  buttzeros(n, Wn1, p_data, bd_size, z_data, &z_size, &dd);
  c_size_idx_1 = bd_size + 1;
  b_c_data[0].re = 1.0;
  b_c_data[0].im = 0.0;
  for (ps_size = 0; ps_size < bd_size; ps_size++) {
    ks = -p_data[ps_size].re;
    u_idx_0 = -p_data[ps_size].im;
    u_idx_1 = b_c_data[ps_size].im;
    d = b_c_data[ps_size].re;
    b_c_data[ps_size + 1].re = ks * d - u_idx_0 * u_idx_1;
    b_c_data[ps_size + 1].im = ks * u_idx_1 + u_idx_0 * d;
    for (b_size = ps_size + 1; b_size >= 2; b_size--) {
      u_idx_1 = p_data[ps_size].re;
      d = p_data[ps_size].im;
      u_idx_0 = u_idx_1 * b_c_data[b_size - 2].im + d * b_c_data[b_size - 2].re;
      b_c_data[b_size - 1].re -=
          u_idx_1 * b_c_data[b_size - 2].re - d * b_c_data[b_size - 2].im;
      b_c_data[b_size - 1].im -= u_idx_0;
    }
  }
  varargout_2_size[0] = 1;
  varargout_2_size[1] = bd_size + 1;
  for (b_size = 0; b_size < c_size_idx_1; b_size++) {
    varargout_2_data[b_size] = b_c_data[b_size].re;
  }
  c_size_idx_1 = z_size + 1;
  b_c_data[0].re = 1.0;
  b_c_data[0].im = 0.0;
  for (ps_size = 0; ps_size < z_size; ps_size++) {
    ks = -z_data[ps_size].re;
    u_idx_0 = -z_data[ps_size].im;
    u_idx_1 = b_c_data[ps_size].im;
    d = b_c_data[ps_size].re;
    b_c_data[ps_size + 1].re = ks * d - u_idx_0 * u_idx_1;
    b_c_data[ps_size + 1].im = ks * u_idx_1 + u_idx_0 * d;
    for (b_size = ps_size + 1; b_size >= 2; b_size--) {
      u_idx_1 = z_data[ps_size].re;
      d = z_data[ps_size].im;
      u_idx_0 = u_idx_1 * b_c_data[b_size - 2].im + d * b_c_data[b_size - 2].re;
      b_c_data[b_size - 1].re -=
          u_idx_1 * b_c_data[b_size - 2].re - d * b_c_data[b_size - 2].im;
      b_c_data[b_size - 1].im -= u_idx_0;
    }
  }
  ps_size = bd_size - z_size;
  varargout_1_size[0] = 1;
  varargout_1_size[1] = (ps_size + z_size) + 1;
  if (0 <= ps_size - 1) {
    std::memset(&varargout_1_data[0], 0, ps_size * sizeof(double));
  }
  for (b_size = 0; b_size < c_size_idx_1; b_size++) {
    varargout_1_data[b_size + ps_size] = dd * b_c_data[b_size].re;
  }
}

static void buttzeros(double n, double Wn, const creal_T p_data[], int p_size,
                      creal_T z_data[], int *z_size, double *k)
{
  creal_T x_data[1002];
  double d;
  double im;
  double r;
  double y_re;
  double zWn_im;
  double zWn_re;
  double zWn_re_tmp;
  int i;
  int loop_ub;
  signed char b_x_data[1000];
  boolean_T exitg1;
  boolean_T y;
  *z_size = static_cast<int>(n) + static_cast<int>(n);
  loop_ub = static_cast<int>(n);
  for (i = 0; i < loop_ub; i++) {
    z_data[i].re = 1.0;
    z_data[i].im = 0.0;
  }
  loop_ub = static_cast<int>(n);
  for (i = 0; i < loop_ub; i++) {
    int i1;
    i1 = i + static_cast<int>(n);
    z_data[i1].re = -1.0;
    z_data[i1].im = 0.0;
  }
  zWn_re_tmp = 2.0 * rt_atan2d_snf(Wn, 4.0);
  zWn_re = zWn_re_tmp * 0.0;
  if (zWn_re_tmp == 0.0) {
    zWn_re = std::exp(zWn_re);
    zWn_im = 0.0;
  } else {
    r = std::exp(zWn_re / 2.0);
    zWn_re = r * (r * std::cos(zWn_re_tmp));
    zWn_im = r * (r * std::sin(zWn_re_tmp));
  }
  for (i = 0; i < p_size; i++) {
    x_data[i].re = zWn_re - p_data[i].re;
    x_data[i].im = zWn_im - p_data[i].im;
  }
  if (p_size == 0) {
    y_re = 1.0;
    im = 0.0;
  } else {
    y_re = x_data[0].re;
    im = x_data[0].im;
    for (loop_ub = 2; loop_ub <= p_size; loop_ub++) {
      r = x_data[loop_ub - 1].re;
      d = x_data[loop_ub - 1].im;
      zWn_re_tmp = y_re * r - im * d;
      im = y_re * d + im * r;
      y_re = zWn_re_tmp;
    }
  }
  for (i = 0; i < *z_size; i++) {
    x_data[i].re = zWn_re - z_data[i].re;
    x_data[i].im = zWn_im - z_data[i].im;
  }
  if (*z_size == 0) {
    zWn_re = 1.0;
    zWn_im = 0.0;
  } else {
    zWn_re = x_data[0].re;
    zWn_im = x_data[0].im;
    for (loop_ub = 2; loop_ub <= *z_size; loop_ub++) {
      r = x_data[loop_ub - 1].re;
      d = x_data[loop_ub - 1].im;
      zWn_re_tmp = zWn_re * r - zWn_im * d;
      zWn_im = zWn_re * d + zWn_im * r;
      zWn_re = zWn_re_tmp;
    }
  }
  if (zWn_im == 0.0) {
    if (im == 0.0) {
      *k = y_re / zWn_re;
    } else if (y_re == 0.0) {
      *k = 0.0;
    } else {
      *k = y_re / zWn_re;
    }
  } else if (zWn_re == 0.0) {
    if (y_re == 0.0) {
      *k = im / zWn_im;
    } else if (im == 0.0) {
      *k = 0.0;
    } else {
      *k = im / zWn_im;
    }
  } else {
    zWn_re_tmp = std::abs(zWn_re);
    r = std::abs(zWn_im);
    if (zWn_re_tmp > r) {
      zWn_re_tmp = zWn_im / zWn_re;
      *k = (y_re + zWn_re_tmp * im) / (zWn_re + zWn_re_tmp * zWn_im);
    } else if (r == zWn_re_tmp) {
      if (zWn_re > 0.0) {
        zWn_re = 0.5;
      } else {
        zWn_re = -0.5;
      }
      if (zWn_im > 0.0) {
        zWn_im = 0.5;
      } else {
        zWn_im = -0.5;
      }
      *k = (y_re * zWn_re + im * zWn_im) / zWn_re_tmp;
    } else {
      zWn_re_tmp = zWn_re / zWn_im;
      *k = (zWn_re_tmp * y_re + im) / (zWn_im + zWn_re_tmp * zWn_re);
    }
  }
  for (i = 0; i < *z_size; i++) {
    b_x_data[i] = static_cast<signed char>(z_data[i].im);
  }
  y = false;
  loop_ub = 1;
  exitg1 = false;
  while ((!exitg1) && (loop_ub <= *z_size)) {
    if (b_x_data[loop_ub - 1] == 0) {
      loop_ub++;
    } else {
      y = true;
      exitg1 = true;
    }
  }
  if (!y) {
    for (i = 0; i < *z_size; i++) {
      z_data[i].im = 0.0;
    }
  }
}

static void eig(const ::coder::array<double, 2U> &A, creal_T V_data[],
                int *V_size)
{
  creal_T beta1_data[1002];
  double tmp_data[1002];
  int k;
  int nx;
  *V_size = A.size(0);
  if ((A.size(0) != 0) && (A.size(1) != 0)) {
    boolean_T p;
    nx = A.size(0) * A.size(1);
    p = true;
    for (k = 0; k < nx; k++) {
      if ((!p) || (std::isinf(A[k]) || std::isnan(A[k]))) {
        p = false;
      }
    }
    if (!p) {
      *V_size = A.size(0);
      nx = A.size(0);
      for (k = 0; k < nx; k++) {
        V_data[k].re = rtNaN;
        V_data[k].im = 0.0;
      }
    } else {
      p = (A.size(0) == A.size(1));
      if (p) {
        boolean_T exitg2;
        nx = 0;
        exitg2 = false;
        while ((!exitg2) && (nx <= A.size(1) - 1)) {
          int exitg1;
          k = 0;
          do {
            exitg1 = 0;
            if (k <= nx) {
              if (!(A[k + A.size(0) * nx] == A[nx + A.size(0) * k])) {
                p = false;
                exitg1 = 1;
              } else {
                k++;
              }
            } else {
              nx++;
              exitg1 = 2;
            }
          } while (exitg1 == 0);
          if (exitg1 == 1) {
            exitg2 = true;
          }
        }
      }
      if (p) {
        eigHermitianStandard(A, tmp_data, V_size);
        for (k = 0; k < *V_size; k++) {
          V_data[k].re = tmp_data[k];
          V_data[k].im = 0.0;
        }
      } else {
        internal::reflapack::xzgeev(A, &nx, V_data, V_size, beta1_data, &k);
        for (k = 0; k < *V_size; k++) {
          double ai;
          double ar;
          double bi;
          double br;
          double im;
          double re;
          ar = V_data[k].re;
          ai = V_data[k].im;
          br = beta1_data[k].re;
          bi = beta1_data[k].im;
          if (bi == 0.0) {
            if (ai == 0.0) {
              re = ar / br;
              im = 0.0;
            } else if (ar == 0.0) {
              re = 0.0;
              im = ai / br;
            } else {
              re = ar / br;
              im = ai / br;
            }
          } else if (br == 0.0) {
            if (ar == 0.0) {
              re = ai / bi;
              im = 0.0;
            } else if (ai == 0.0) {
              re = 0.0;
              im = -(ar / bi);
            } else {
              re = ai / bi;
              im = -(ar / bi);
            }
          } else {
            double brm;
            brm = std::abs(br);
            im = std::abs(bi);
            if (brm > im) {
              double s;
              s = bi / br;
              im = br + s * bi;
              re = (ar + s * ai) / im;
              im = (ai - s * ar) / im;
            } else if (im == brm) {
              double s;
              if (br > 0.0) {
                s = 0.5;
              } else {
                s = -0.5;
              }
              if (bi > 0.0) {
                im = 0.5;
              } else {
                im = -0.5;
              }
              re = (ar * s + ai * im) / brm;
              im = (ai * s - ar * im) / brm;
            } else {
              double s;
              s = br / bi;
              im = bi + s * br;
              re = (s * ar + ai) / im;
              im = (s * ai - ar) / im;
            }
          }
          V_data[k].re = re;
          V_data[k].im = im;
        }
      }
    }
  }
}

static void eigHermitianStandard(const ::coder::array<double, 2U> &A,
                                 double V_data[], int *V_size)
{
  array<double, 2U> T;
  array<double, 2U> b_A;
  int istart;
  int nx;
  boolean_T p;
  b_A.set_size(A.size(0), A.size(1));
  nx = A.size(0) * A.size(1) - 1;
  for (istart = 0; istart <= nx; istart++) {
    b_A[istart] = A[istart];
  }
  nx = b_A.size(0) * b_A.size(1);
  p = true;
  for (istart = 0; istart < nx; istart++) {
    if ((!p) || (std::isinf(b_A[istart]) || std::isnan(b_A[istart]))) {
      p = false;
    }
  }
  if (!p) {
    T.set_size(static_cast<int>(static_cast<short>(b_A.size(0))),
               static_cast<int>(static_cast<short>(b_A.size(1))));
    nx = static_cast<short>(b_A.size(0)) * static_cast<short>(b_A.size(1));
    for (istart = 0; istart < nx; istart++) {
      T[istart] = rtNaN;
    }
    nx = static_cast<short>(b_A.size(0));
    if ((static_cast<short>(b_A.size(0)) != 0) &&
        (static_cast<short>(b_A.size(1)) != 0) &&
        (1 < static_cast<short>(b_A.size(0)))) {
      int jend;
      istart = 2;
      if (static_cast<short>(b_A.size(0)) - 2 <
          static_cast<short>(b_A.size(1)) - 1) {
        jend = static_cast<short>(b_A.size(0)) - 1;
      } else {
        jend = static_cast<short>(b_A.size(1));
      }
      for (int j{0}; j < jend; j++) {
        for (int i{istart}; i <= nx; i++) {
          T[(i + T.size(0) * j) - 1] = 0.0;
        }
        istart++;
      }
    }
  } else {
    internal::lapack::xgehrd(b_A);
    T.set_size(b_A.size(0), b_A.size(1));
    nx = b_A.size(0) * b_A.size(1);
    for (istart = 0; istart < nx; istart++) {
      T[istart] = b_A[istart];
    }
    internal::reflapack::eml_dlahqr(T);
    nx = T.size(0);
    if ((T.size(0) != 0) && (T.size(1) != 0) && (3 < T.size(0))) {
      int jend;
      istart = 4;
      if (T.size(0) - 4 < T.size(1) - 1) {
        jend = T.size(0) - 3;
      } else {
        jend = T.size(1);
      }
      for (int j{0}; j < jend; j++) {
        for (int i{istart}; i <= nx; i++) {
          T[(i + T.size(0) * j) - 1] = 0.0;
        }
        istart++;
      }
    }
  }
  nx = T.size(0);
  *V_size = T.size(0);
  for (istart = 0; istart < nx; istart++) {
    V_data[istart] = T[istart + T.size(0) * istart];
  }
}

namespace internal {
static void b_lusolve(const ::coder::array<double, 2U> &A, double B_data[],
                      const int B_size[2])
{
  array<double, 2U> b_A;
  int ipiv_data[1002];
  int ipiv_size[2];
  int i;
  int i1;
  int j;
  int jAcol;
  int k;
  int n;
  n = A.size(1);
  b_A.set_size(A.size(0), A.size(1));
  jAcol = A.size(0) * A.size(1);
  for (i = 0; i < jAcol; i++) {
    b_A[i] = A[i];
  }
  lapack::xgetrf(A.size(1), A.size(1), b_A, A.size(1), ipiv_data, ipiv_size,
                 &jAcol);
  if ((A.size(1) != 0) && (B_size[1] != 0)) {
    for (j = 0; j < n; j++) {
      jAcol = n * j;
      for (k = 0; k < j; k++) {
        i = k + jAcol;
        if (b_A[i] != 0.0) {
          B_data[j] -= b_A[i] * B_data[k];
        }
      }
      B_data[j] *= 1.0 / b_A[j + jAcol];
    }
  }
  if ((A.size(1) != 0) && (B_size[1] != 0)) {
    for (j = n; j >= 1; j--) {
      jAcol = n * (j - 1) - 1;
      i = j + 1;
      for (k = i; k <= n; k++) {
        i1 = k + jAcol;
        if (b_A[i1] != 0.0) {
          B_data[j - 1] -= b_A[i1] * B_data[k - 1];
        }
      }
    }
  }
  i = A.size(1) - 1;
  for (j = i; j >= 1; j--) {
    i1 = ipiv_data[j - 1];
    if (i1 != j) {
      double temp;
      temp = B_data[j - 1];
      B_data[j - 1] = B_data[i1 - 1];
      B_data[i1 - 1] = temp;
    }
  }
}

namespace blas {
static void xgerc(int m, int n, double alpha1, int ix0, const double y_data[],
                  ::coder::array<double, 2U> &A, int ia0, int lda)
{
  if (!(alpha1 == 0.0)) {
    int jA;
    jA = ia0;
    for (int j{0}; j < n; j++) {
      if (y_data[j] != 0.0) {
        double temp;
        int i;
        temp = y_data[j] * alpha1;
        i = m + jA;
        for (int ijA{jA}; ijA < i; ijA++) {
          A[ijA - 1] = A[ijA - 1] + A[((ix0 + ijA) - jA) - 1] * temp;
        }
      }
      jA += lda;
    }
  }
}

static double xnrm2(int n, const double x[3])
{
  double y;
  y = 0.0;
  if (n >= 1) {
    if (n == 1) {
      y = std::abs(x[1]);
    } else {
      double absxk;
      double scale;
      double t;
      scale = 3.3121686421112381E-170;
      absxk = std::abs(x[1]);
      if (absxk > 3.3121686421112381E-170) {
        y = 1.0;
        scale = absxk;
      } else {
        t = absxk / 3.3121686421112381E-170;
        y = t * t;
      }
      absxk = std::abs(x[2]);
      if (absxk > scale) {
        t = scale / absxk;
        y = y * t * t + 1.0;
        scale = absxk;
      } else {
        t = absxk / scale;
        y += t * t;
      }
      y = scale * std::sqrt(y);
    }
  }
  return y;
}

static double xnrm2(int n, const ::coder::array<double, 2U> &x, int ix0)
{
  double y;
  y = 0.0;
  if (n >= 1) {
    if (n == 1) {
      y = std::abs(x[ix0 - 1]);
    } else {
      double scale;
      int kend;
      scale = 3.3121686421112381E-170;
      kend = (ix0 + n) - 1;
      for (int k{ix0}; k <= kend; k++) {
        double absxk;
        absxk = std::abs(x[k - 1]);
        if (absxk > scale) {
          double t;
          t = scale / absxk;
          y = y * t * t + 1.0;
          scale = absxk;
        } else {
          double t;
          t = absxk / scale;
          y += t * t;
        }
      }
      y = scale * std::sqrt(y);
    }
  }
  return y;
}

} // namespace blas
static boolean_T cplxpairv(creal_T x_data[], const int *x_size, double tol)
{
  double absx_data[501];
  double zi_data[501];
  double zr_data[501];
  double absxk;
  int b_iwork_data[501];
  int idx_data[501];
  int iwork_data[501];
  int b_i;
  int i;
  int i1;
  int i2;
  int j;
  int k;
  int kEnd;
  int n;
  int nc;
  int nr;
  int p;
  int pEnd;
  int q;
  int qEnd;
  boolean_T exitg1;
  boolean_T pairable;
  n = *x_size;
  i1 = *x_size;
  for (i = 0; i < *x_size; i++) {
    zr_data[i] = x_data[i].re;
  }
  nr = static_cast<short>(i1);
  if (0 <= nr - 1) {
    std::memset(&idx_data[0], 0, nr * sizeof(int));
  }
  i = i1 - 1;
  for (k = 1; k <= i; k += 2) {
    absxk = zr_data[k];
    if ((zr_data[k - 1] <= absxk) || std::isnan(absxk)) {
      idx_data[k - 1] = k;
      idx_data[k] = k + 1;
    } else {
      idx_data[k - 1] = k + 1;
      idx_data[k] = k;
    }
  }
  if ((i1 & 1) != 0) {
    idx_data[i1 - 1] = i1;
  }
  b_i = 2;
  while (b_i < i1) {
    i2 = b_i << 1;
    j = 1;
    for (pEnd = b_i + 1; pEnd < i1 + 1; pEnd = qEnd + b_i) {
      p = j;
      q = pEnd - 1;
      qEnd = j + i2;
      if (qEnd > i1 + 1) {
        qEnd = i1 + 1;
      }
      k = 0;
      kEnd = qEnd - j;
      while (k + 1 <= kEnd) {
        absxk = zr_data[idx_data[q] - 1];
        i = idx_data[p - 1];
        if ((zr_data[i - 1] <= absxk) || std::isnan(absxk)) {
          iwork_data[k] = i;
          p++;
          if (p == pEnd) {
            while (q + 1 < qEnd) {
              k++;
              iwork_data[k] = idx_data[q];
              q++;
            }
          }
        } else {
          iwork_data[k] = idx_data[q];
          q++;
          if (q + 1 == qEnd) {
            while (p < pEnd) {
              k++;
              iwork_data[k] = idx_data[p - 1];
              p++;
            }
          }
        }
        k++;
      }
      for (k = 0; k < kEnd; k++) {
        idx_data[(j + k) - 1] = iwork_data[k];
      }
      j = qEnd;
    }
    b_i = i2;
  }
  nr = 0;
  nc = -1;
  for (k = 0; k < n; k++) {
    i = idx_data[k];
    absxk = rt_hypotd_snf(x_data[i - 1].re, x_data[i - 1].im);
    if (std::abs(x_data[i - 1].im) <= tol * absxk) {
      nr++;
      i1 = n - nr;
      zr_data[i1] = x_data[i - 1].re;
      zi_data[i1] = 0.0;
      absx_data[k] = absxk;
    } else {
      nc++;
      zr_data[nc] = x_data[i - 1].re;
      zi_data[nc] = x_data[i - 1].im;
      absx_data[nc] = absxk;
    }
  }
  for (k = 0; k < nr; k++) {
    i = (nc + k) + 1;
    x_data[i].re = zr_data[(n - k) - 1];
    x_data[i].im = 0.0;
  }
  for (k = 0; k <= nc; k++) {
    x_data[k].re = zr_data[k];
    x_data[k].im = zi_data[k];
  }
  pairable = (((nc + 1) & 1) != 1);
  if (pairable) {
    k = 1;
    exitg1 = false;
    while ((!exitg1) && (k <= nc + 1)) {
      if (zr_data[k] - zr_data[k - 1] > tol * absx_data[k - 1]) {
        pairable = false;
        exitg1 = true;
      } else {
        k += 2;
      }
    }
  }
  if (pairable) {
    k = 1;
    exitg1 = false;
    while ((!exitg1) && (k < nc + 1)) {
      int ng;
      int offset;
      absxk = zr_data[k - 1];
      n = k;
      offset = k - 2;
      while ((k < nc + 1) && (zr_data[k] - absxk <= tol * absx_data[k - 1])) {
        k++;
      }
      ng = (k - n) + 1;
      nr = ng & 1;
      pairable = (nr == 0);
      if (!pairable) {
        exitg1 = true;
      } else {
        int b_k;
        boolean_T exitg2;
        i = ng - 1;
        for (b_k = 1; b_k <= i; b_k += 2) {
          i1 = offset + b_k;
          absxk = zi_data[i1 + 1];
          if ((zi_data[i1] <= absxk) || std::isnan(absxk)) {
            idx_data[i1] = b_k;
            idx_data[i1 + 1] = b_k + 1;
          } else {
            idx_data[i1] = b_k + 1;
            idx_data[i1 + 1] = b_k;
          }
        }
        if (nr != 0) {
          idx_data[offset + ng] = ng;
        }
        b_i = 2;
        while (b_i < ng) {
          i2 = b_i << 1;
          j = 1;
          for (pEnd = b_i + 1; pEnd < ng + 1; pEnd = qEnd + b_i) {
            p = j;
            q = pEnd;
            qEnd = j + i2;
            if (qEnd > ng + 1) {
              qEnd = ng + 1;
            }
            b_k = 0;
            kEnd = qEnd - j;
            while (b_k + 1 <= kEnd) {
              nr = idx_data[offset + q];
              absxk = zi_data[offset + nr];
              i = idx_data[offset + p];
              if ((zi_data[offset + i] <= absxk) || std::isnan(absxk)) {
                b_iwork_data[b_k] = i;
                p++;
                if (p == pEnd) {
                  while (q < qEnd) {
                    b_k++;
                    b_iwork_data[b_k] = idx_data[offset + q];
                    q++;
                  }
                }
              } else {
                b_iwork_data[b_k] = nr;
                q++;
                if (q == qEnd) {
                  while (p < pEnd) {
                    b_k++;
                    b_iwork_data[b_k] = idx_data[offset + p];
                    p++;
                  }
                }
              }
              b_k++;
            }
            for (b_k = 0; b_k < kEnd; b_k++) {
              idx_data[(offset + j) + b_k] = b_iwork_data[b_k];
            }
            j = qEnd;
          }
          b_i = i2;
        }
        j = n;
        exitg2 = false;
        while ((!exitg2) && (j <= k)) {
          i1 = offset + idx_data[j - 1];
          if (std::abs(zi_data[i1] +
                       zi_data[offset + idx_data[((k - j) + n) - 1]]) >
              tol * absx_data[i1]) {
            pairable = false;
            exitg2 = true;
          } else {
            j++;
          }
        }
        if (!pairable) {
          exitg1 = true;
        } else {
          nr = ng >> 1;
          for (j = 0; j < nr; j++) {
            i1 = offset + idx_data[(k - j) - 1];
            i = offset + ((j + 1) << 1);
            x_data[i - 1].re = zr_data[i1];
            x_data[i - 1].im = -zi_data[i1];
            x_data[i].re = zr_data[i1];
            x_data[i].im = zi_data[i1];
          }
          k++;
        }
      }
    }
  }
  return pairable;
}

namespace lapack {
static void xgehrd(::coder::array<double, 2U> &a)
{
  double work_data[1002];
  double tau_data[1001];
  double alpha1;
  int b_i;
  int i;
  int n;
  short unnamed_idx_0;
  n = a.size(0);
  unnamed_idx_0 = static_cast<short>(a.size(0));
  i = unnamed_idx_0;
  if (0 <= i - 1) {
    std::memset(&work_data[0], 0, i * sizeof(double));
  }
  b_i = a.size(0);
  for (int c_i{0}; c_i <= b_i - 2; c_i++) {
    double temp;
    int exitg1;
    int i1;
    int i2;
    int ia;
    int iac;
    int ic0;
    int in;
    int iv0_tmp;
    int lastc;
    int lastv;
    int n_tmp_tmp;
    boolean_T exitg2;
    in = (c_i + 1) * n;
    alpha1 = a[(c_i + a.size(0) * c_i) + 1];
    i = c_i + 3;
    if (i >= n) {
      i = n;
    }
    temp = reflapack::xzlarfg((n - c_i) - 1, &alpha1, a, i + c_i * n);
    tau_data[c_i] = temp;
    a[(c_i + a.size(0) * c_i) + 1] = 1.0;
    n_tmp_tmp = n - c_i;
    iv0_tmp = (c_i + c_i * n) + 2;
    ic0 = in + 1;
    if (temp != 0.0) {
      lastv = n_tmp_tmp - 2;
      i = (iv0_tmp + n_tmp_tmp) - 4;
      while ((lastv + 1 > 0) && (a[i + 1] == 0.0)) {
        lastv--;
        i--;
      }
      lastc = n;
      exitg2 = false;
      while ((!exitg2) && (lastc > 0)) {
        i = in + lastc;
        ia = i;
        do {
          exitg1 = 0;
          if ((n > 0) && (ia <= i + lastv * n)) {
            if (a[ia - 1] != 0.0) {
              exitg1 = 1;
            } else {
              ia += n;
            }
          } else {
            lastc--;
            exitg1 = 2;
          }
        } while (exitg1 == 0);
        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
    } else {
      lastv = -1;
      lastc = 0;
    }
    if (lastv + 1 > 0) {
      int work_tmp;
      if (lastc != 0) {
        if (0 <= lastc - 1) {
          std::memset(&work_data[0], 0, lastc * sizeof(double));
        }
        i = iv0_tmp - 1;
        i1 = (in + n * lastv) + 1;
        for (iac = ic0; n < 0 ? iac >= i1 : iac <= i1; iac += n) {
          i2 = (iac + lastc) - 1;
          for (ia = iac; ia <= i2; ia++) {
            work_tmp = ia - iac;
            work_data[work_tmp] += a[ia - 1] * a[i];
          }
          i++;
        }
      }
      if (!(-tau_data[c_i] == 0.0)) {
        i = in;
        for (work_tmp = 0; work_tmp <= lastv; work_tmp++) {
          i1 = (iv0_tmp + work_tmp) - 1;
          if (a[i1] != 0.0) {
            temp = a[i1] * -tau_data[c_i];
            i1 = i + 1;
            i2 = lastc + i;
            for (iac = i1; iac <= i2; iac++) {
              a[iac - 1] = a[iac - 1] + work_data[(iac - i) - 1] * temp;
            }
          }
          i += n;
        }
      }
    }
    ic0 = (c_i + in) + 2;
    if (tau_data[c_i] != 0.0) {
      lastv = n_tmp_tmp - 1;
      i = (iv0_tmp + n_tmp_tmp) - 3;
      while ((lastv > 0) && (a[i] == 0.0)) {
        lastv--;
        i--;
      }
      lastc = n_tmp_tmp - 1;
      exitg2 = false;
      while ((!exitg2) && (lastc > 0)) {
        i = ic0 + (lastc - 1) * n;
        ia = i;
        do {
          exitg1 = 0;
          if (ia <= (i + lastv) - 1) {
            if (a[ia - 1] != 0.0) {
              exitg1 = 1;
            } else {
              ia++;
            }
          } else {
            lastc--;
            exitg1 = 2;
          }
        } while (exitg1 == 0);
        if (exitg1 == 1) {
          exitg2 = true;
        }
      }
    } else {
      lastv = 0;
      lastc = 0;
    }
    if (lastv > 0) {
      if (lastc != 0) {
        if (0 <= lastc - 1) {
          std::memset(&work_data[0], 0, lastc * sizeof(double));
        }
        i = 0;
        i1 = ic0 + n * (lastc - 1);
        for (iac = ic0; n < 0 ? iac >= i1 : iac <= i1; iac += n) {
          temp = 0.0;
          i2 = (iac + lastv) - 1;
          for (ia = iac; ia <= i2; ia++) {
            temp += a[ia - 1] * a[((iv0_tmp + ia) - iac) - 1];
          }
          work_data[i] += temp;
          i++;
        }
      }
      blas::xgerc(lastv, lastc, -tau_data[c_i], iv0_tmp, work_data, a, ic0, n);
    }
    a[(c_i + a.size(0) * c_i) + 1] = alpha1;
  }
}

static void xgeqp3(::coder::array<double, 2U> &A, double tau_data[],
                   int *tau_size, int jpvt_data[], int jpvt_size[2])
{
  int n;
  int u0;
  boolean_T guard1{false};
  n = A.size(1) - 1;
  u0 = A.size(0);
  *tau_size = A.size(1);
  if (u0 < *tau_size) {
    *tau_size = u0;
  }
  if (0 <= *tau_size - 1) {
    std::memset(&tau_data[0], 0, *tau_size * sizeof(double));
  }
  guard1 = false;
  if ((A.size(0) == 0) || (A.size(1) == 0)) {
    guard1 = true;
  } else {
    int u1;
    u0 = A.size(0);
    u1 = A.size(1);
    if (u0 < u1) {
      u1 = u0;
    }
    if (u1 < 1) {
      guard1 = true;
    } else {
      jpvt_size[0] = 1;
      jpvt_size[1] = A.size(1);
      u0 = A.size(1);
      if (0 <= u0 - 1) {
        std::memset(&jpvt_data[0], 0, u0 * sizeof(int));
      }
      for (u0 = 0; u0 <= n; u0++) {
        jpvt_data[u0] = u0 + 1;
      }
      reflapack::qrpf(A, A.size(0), A.size(1), tau_data, jpvt_data);
    }
  }
  if (guard1) {
    jpvt_size[0] = 1;
    jpvt_size[1] = A.size(1);
    u0 = A.size(1);
    if (0 <= u0 - 1) {
      std::memset(&jpvt_data[0], 0, u0 * sizeof(int));
    }
    for (u0 = 0; u0 <= n; u0++) {
      jpvt_data[u0] = u0 + 1;
    }
  }
}

static void xgetrf(int m, int n, ::coder::array<double, 2U> &A, int lda,
                   int ipiv_data[], int ipiv_size[2], int *info)
{
  int b_n;
  int k;
  int yk;
  if (m < n) {
    yk = m;
  } else {
    yk = n;
  }
  if (yk < 1) {
    b_n = 0;
  } else {
    b_n = yk;
  }
  ipiv_size[0] = 1;
  ipiv_size[1] = b_n;
  if (b_n > 0) {
    ipiv_data[0] = 1;
    yk = 1;
    for (k = 2; k <= b_n; k++) {
      yk++;
      ipiv_data[k - 1] = yk;
    }
  }
  *info = 0;
  if ((m >= 1) && (n >= 1)) {
    int u0;
    u0 = m - 1;
    if (u0 >= n) {
      u0 = n;
    }
    for (int j{0}; j < u0; j++) {
      double smax;
      int b_tmp;
      int i;
      int ipiv_tmp;
      int jA;
      int jp1j;
      int mmj;
      mmj = m - j;
      b_tmp = j * (lda + 1);
      jp1j = b_tmp + 2;
      if (mmj < 1) {
        yk = -1;
      } else {
        yk = 0;
        if (mmj > 1) {
          smax = std::abs(A[b_tmp]);
          for (k = 2; k <= mmj; k++) {
            double s;
            s = std::abs(A[(b_tmp + k) - 1]);
            if (s > smax) {
              yk = k - 1;
              smax = s;
            }
          }
        }
      }
      if (A[b_tmp + yk] != 0.0) {
        if (yk != 0) {
          ipiv_tmp = j + yk;
          ipiv_data[j] = ipiv_tmp + 1;
          for (k = 0; k < n; k++) {
            yk = k * lda;
            jA = j + yk;
            smax = A[jA];
            i = ipiv_tmp + yk;
            A[jA] = A[i];
            A[i] = smax;
          }
        }
        i = b_tmp + mmj;
        for (yk = jp1j; yk <= i; yk++) {
          A[yk - 1] = A[yk - 1] / A[b_tmp];
        }
      } else {
        *info = j + 1;
      }
      b_n = n - j;
      ipiv_tmp = b_tmp + lda;
      jA = ipiv_tmp;
      for (k = 0; k <= b_n - 2; k++) {
        yk = ipiv_tmp + k * lda;
        smax = A[yk];
        if (A[yk] != 0.0) {
          i = jA + 2;
          yk = mmj + jA;
          for (jp1j = i; jp1j <= yk; jp1j++) {
            A[jp1j - 1] = A[jp1j - 1] + A[((b_tmp + jp1j) - jA) - 1] * -smax;
          }
        }
        jA += lda;
      }
    }
    if ((*info == 0) && (m <= n) &&
        (!(A[(m + A.size(0) * (m - 1)) - 1] != 0.0))) {
      *info = m;
    }
  }
}

} // namespace lapack
static void lusolve(const ::coder::array<double, 2U> &A,
                    const ::coder::array<double, 2U> &B,
                    ::coder::array<double, 2U> &X)
{
  array<double, 2U> b_A;
  int ipiv_data[1002];
  int ipiv_size[2];
  int LDA;
  int LDB;
  int b_i;
  int i;
  int i1;
  int j;
  int jBcol;
  int k;
  int kAcol;
  int n;
  int nrhs;
  X.set_size(B.size(0), B.size(1));
  LDA = B.size(0) * B.size(1);
  for (i = 0; i < LDA; i++) {
    X[i] = B[i];
  }
  LDA = A.size(0);
  n = A.size(1);
  if (LDA < n) {
    n = LDA;
  }
  LDA = B.size(0);
  if (LDA < n) {
    n = LDA;
  }
  nrhs = B.size(1) - 1;
  b_A.set_size(A.size(0), A.size(1));
  LDA = A.size(0) * A.size(1);
  for (i = 0; i < LDA; i++) {
    b_A[i] = A[i];
  }
  lapack::xgetrf(n, n, b_A, A.size(0), ipiv_data, ipiv_size, &LDA);
  LDA = b_A.size(0);
  LDB = B.size(0);
  for (b_i = 0; b_i <= n - 2; b_i++) {
    i = ipiv_data[b_i];
    if (i != b_i + 1) {
      for (j = 0; j <= nrhs; j++) {
        double temp;
        temp = X[b_i + X.size(0) * j];
        X[b_i + X.size(0) * j] = X[(i + X.size(0) * j) - 1];
        X[(i + X.size(0) * j) - 1] = temp;
      }
    }
  }
  if ((B.size(1) != 0) && ((X.size(0) != 0) && (X.size(1) != 0))) {
    for (j = 0; j <= nrhs; j++) {
      jBcol = LDB * j;
      for (k = 0; k < n; k++) {
        kAcol = LDA * k;
        i = k + jBcol;
        if (X[i] != 0.0) {
          i1 = k + 2;
          for (b_i = i1; b_i <= n; b_i++) {
            int i2;
            i2 = (b_i + jBcol) - 1;
            X[i2] = X[i2] - X[i] * b_A[(b_i + kAcol) - 1];
          }
        }
      }
    }
  }
  if ((B.size(1) != 0) && ((X.size(0) != 0) && (X.size(1) != 0))) {
    for (j = 0; j <= nrhs; j++) {
      jBcol = LDB * j - 1;
      for (k = n; k >= 1; k--) {
        kAcol = LDA * (k - 1) - 1;
        i = k + jBcol;
        if (X[i] != 0.0) {
          X[i] = X[i] / b_A[k + kAcol];
          for (b_i = 0; b_i <= k - 2; b_i++) {
            i1 = (b_i + jBcol) + 1;
            X[i1] = X[i1] - X[i] * b_A[(b_i + kAcol) + 1];
          }
        }
      }
    }
  }
}

static void lusolve(const ::coder::array<double, 2U> &A, double B_data[],
                    const int *B_size)
{
  array<double, 2U> b_A;
  double temp;
  int ipiv_data[1002];
  int ipiv_size[2];
  int LDA;
  int b_i;
  int i;
  int k;
  int kAcol;
  int n;
  LDA = A.size(0);
  n = A.size(1);
  if (LDA < n) {
    n = LDA;
  }
  LDA = *B_size;
  if (LDA < n) {
    n = LDA;
  }
  b_A.set_size(A.size(0), A.size(1));
  LDA = A.size(0) * A.size(1);
  for (i = 0; i < LDA; i++) {
    b_A[i] = A[i];
  }
  lapack::xgetrf(n, n, b_A, A.size(0), ipiv_data, ipiv_size, &LDA);
  LDA = b_A.size(0);
  for (b_i = 0; b_i <= n - 2; b_i++) {
    i = ipiv_data[b_i];
    if (i != b_i + 1) {
      temp = B_data[b_i];
      B_data[b_i] = B_data[i - 1];
      B_data[i - 1] = temp;
    }
  }
  for (k = 0; k < n; k++) {
    kAcol = LDA * k;
    if (B_data[k] != 0.0) {
      i = k + 2;
      for (b_i = i; b_i <= n; b_i++) {
        B_data[b_i - 1] -= B_data[k] * b_A[(b_i + kAcol) - 1];
      }
    }
  }
  for (k = n; k >= 1; k--) {
    kAcol = LDA * (k - 1);
    temp = B_data[k - 1];
    if (temp != 0.0) {
      B_data[k - 1] = temp / b_A[(k + kAcol) - 1];
      for (b_i = 0; b_i <= k - 2; b_i++) {
        B_data[b_i] -= B_data[k - 1] * b_A[b_i + kAcol];
      }
    }
  }
}

static void mrdiv(const double A_data[], const int A_size[2],
                  const ::coder::array<double, 2U> &B, double Y_data[],
                  int Y_size[2])
{
  array<double, 2U> b_B;
  double b_A_data[1002];
  double tmp_data[1002];
  int loop_ub;
  if ((A_size[1] == 0) || ((B.size(0) == 0) || (B.size(1) == 0))) {
    Y_size[0] = 1;
    Y_size[1] = static_cast<short>(B.size(0));
    loop_ub = static_cast<short>(B.size(0));
    if (0 <= loop_ub - 1) {
      std::memset(&Y_data[0], 0, loop_ub * sizeof(double));
    }
  } else if (B.size(0) == B.size(1)) {
    Y_size[0] = 1;
    Y_size[1] = A_size[1];
    loop_ub = A_size[1];
    if (0 <= loop_ub - 1) {
      std::copy(&A_data[0], &A_data[loop_ub], &Y_data[0]);
    }
    b_lusolve(B, Y_data, Y_size);
  } else {
    b_B.set_size(B.size(1), B.size(0));
    loop_ub = B.size(0);
    for (int i{0}; i < loop_ub; i++) {
      int b_loop_ub;
      b_loop_ub = B.size(1);
      for (int i1{0}; i1 < b_loop_ub; i1++) {
        b_B[i1 + b_B.size(0) * i] = B[i + B.size(0) * i1];
      }
    }
    loop_ub = A_size[1];
    if (0 <= loop_ub - 1) {
      std::copy(&A_data[0], &A_data[loop_ub], &b_A_data[0]);
    }
    qrsolve(b_B, b_A_data, A_size[1], tmp_data, &loop_ub);
    Y_size[0] = 1;
    Y_size[1] = loop_ub;
    if (0 <= loop_ub - 1) {
      std::copy(&tmp_data[0], &tmp_data[loop_ub], &Y_data[0]);
    }
  }
}

static void qrsolve(const ::coder::array<double, 2U> &A, const double B_data[],
                    int B_size, double Y_data[], int *Y_size)
{
  array<double, 2U> b_A;
  double b_B_data[1002];
  double tau_data[1002];
  int jpvt_data[1002];
  int jpvt_size[2];
  int b_i;
  int i;
  int loop_ub;
  int m;
  int mn;
  int rankA;
  b_A.set_size(A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_A[i] = A[i];
  }
  lapack::xgeqp3(b_A, tau_data, &loop_ub, jpvt_data, jpvt_size);
  if (0 <= B_size - 1) {
    std::copy(&B_data[0], &B_data[B_size], &b_B_data[0]);
  }
  rankA = rankFromQR(b_A);
  *Y_size = static_cast<short>(b_A.size(1));
  loop_ub = static_cast<short>(b_A.size(1));
  if (0 <= loop_ub - 1) {
    std::memset(&Y_data[0], 0, loop_ub * sizeof(double));
  }
  m = b_A.size(0);
  loop_ub = b_A.size(0);
  mn = b_A.size(1);
  if (loop_ub < mn) {
    mn = loop_ub;
  }
  for (loop_ub = 0; loop_ub < mn; loop_ub++) {
    if (tau_data[loop_ub] != 0.0) {
      double wj;
      wj = b_B_data[loop_ub];
      i = loop_ub + 2;
      for (b_i = i; b_i <= m; b_i++) {
        wj += b_A[(b_i + b_A.size(0) * loop_ub) - 1] * b_B_data[b_i - 1];
      }
      wj *= tau_data[loop_ub];
      if (wj != 0.0) {
        b_B_data[loop_ub] -= wj;
        for (b_i = i; b_i <= m; b_i++) {
          b_B_data[b_i - 1] -= b_A[(b_i + b_A.size(0) * loop_ub) - 1] * wj;
        }
      }
    }
  }
  for (b_i = 0; b_i < rankA; b_i++) {
    Y_data[jpvt_data[b_i] - 1] = b_B_data[b_i];
  }
  for (loop_ub = rankA; loop_ub >= 1; loop_ub--) {
    i = jpvt_data[loop_ub - 1];
    Y_data[i - 1] /= b_A[(loop_ub + b_A.size(0) * (loop_ub - 1)) - 1];
    for (b_i = 0; b_i <= loop_ub - 2; b_i++) {
      Y_data[jpvt_data[b_i] - 1] -= Y_data[jpvt_data[loop_ub - 1] - 1] *
                                    b_A[b_i + b_A.size(0) * (loop_ub - 1)];
    }
  }
}

static void qrsolve(const ::coder::array<double, 2U> &A,
                    const ::coder::array<double, 2U> &B,
                    ::coder::array<double, 2U> &Y)
{
  array<double, 2U> b_A;
  array<double, 2U> b_B;
  double tau_data[1002];
  int jpvt_data[1002];
  int jpvt_size[2];
  int b_i;
  int b_nb;
  int i;
  int k;
  int loop_ub;
  int m;
  int mn;
  int nb;
  int rankA;
  b_A.set_size(A.size(0), A.size(1));
  loop_ub = A.size(0) * A.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_A[i] = A[i];
  }
  lapack::xgeqp3(b_A, tau_data, &loop_ub, jpvt_data, jpvt_size);
  b_B.set_size(B.size(0), B.size(1));
  loop_ub = B.size(0) * B.size(1);
  for (i = 0; i < loop_ub; i++) {
    b_B[i] = B[i];
  }
  rankA = rankFromQR(b_A);
  nb = B.size(1);
  Y.set_size(static_cast<int>(static_cast<short>(b_A.size(1))),
             static_cast<int>(static_cast<short>(B.size(1))));
  loop_ub = static_cast<short>(b_A.size(1)) * static_cast<short>(B.size(1));
  for (i = 0; i < loop_ub; i++) {
    Y[i] = 0.0;
  }
  m = b_A.size(0);
  b_nb = B.size(1);
  loop_ub = b_A.size(0);
  mn = b_A.size(1);
  if (loop_ub < mn) {
    mn = loop_ub;
  }
  for (loop_ub = 0; loop_ub < mn; loop_ub++) {
    if (tau_data[loop_ub] != 0.0) {
      for (k = 0; k < b_nb; k++) {
        double wj;
        wj = b_B[loop_ub + b_B.size(0) * k];
        i = loop_ub + 2;
        for (b_i = i; b_i <= m; b_i++) {
          wj += b_A[(b_i + b_A.size(0) * loop_ub) - 1] *
                b_B[(b_i + b_B.size(0) * k) - 1];
        }
        wj *= tau_data[loop_ub];
        if (wj != 0.0) {
          b_B[loop_ub + b_B.size(0) * k] = b_B[loop_ub + b_B.size(0) * k] - wj;
          for (b_i = i; b_i <= m; b_i++) {
            b_B[(b_i + b_B.size(0) * k) - 1] =
                b_B[(b_i + b_B.size(0) * k) - 1] -
                b_A[(b_i + b_A.size(0) * loop_ub) - 1] * wj;
          }
        }
      }
    }
  }
  for (k = 0; k < nb; k++) {
    for (b_i = 0; b_i < rankA; b_i++) {
      Y[(jpvt_data[b_i] + Y.size(0) * k) - 1] = b_B[b_i + b_B.size(0) * k];
    }
    for (loop_ub = rankA; loop_ub >= 1; loop_ub--) {
      i = jpvt_data[loop_ub - 1];
      Y[(i + Y.size(0) * k) - 1] =
          Y[(i + Y.size(0) * k) - 1] /
          b_A[(loop_ub + b_A.size(0) * (loop_ub - 1)) - 1];
      for (b_i = 0; b_i <= loop_ub - 2; b_i++) {
        Y[(jpvt_data[b_i] + Y.size(0) * k) - 1] =
            Y[(jpvt_data[b_i] + Y.size(0) * k) - 1] -
            Y[(jpvt_data[loop_ub - 1] + Y.size(0) * k) - 1] *
                b_A[b_i + b_A.size(0) * (loop_ub - 1)];
      }
    }
  }
}

static int rankFromQR(const ::coder::array<double, 2U> &A)
{
  int maxmn;
  int minmn;
  int r;
  r = 0;
  if (A.size(0) < A.size(1)) {
    minmn = A.size(0);
    maxmn = A.size(1);
  } else {
    minmn = A.size(1);
    maxmn = A.size(0);
  }
  if (minmn > 0) {
    double tol;
    tol = 2.2204460492503131E-15 * static_cast<double>(maxmn) * std::abs(A[0]);
    while ((r < minmn) && (!(std::abs(A[r + A.size(0) * r]) <= tol))) {
      r++;
    }
  }
  return r;
}

namespace reflapack {
static int eml_dlahqr(::coder::array<double, 2U> &h)
{
  double v[3];
  double aa;
  double ab;
  double ba;
  double bb;
  double d;
  double rt1r;
  double rt2r;
  double s;
  double tst;
  int info;
  int ldh;
  int n;
  n = h.size(0);
  ldh = h.size(0);
  info = 0;
  if ((n != 0) && (1 != n)) {
    double SMLNUM;
    int i;
    int itmax;
    int iy;
    boolean_T exitg1;
    v[0] = 0.0;
    v[1] = 0.0;
    v[2] = 0.0;
    for (iy = 0; iy <= n - 4; iy++) {
      h[(iy + h.size(0) * iy) + 2] = 0.0;
      h[(iy + h.size(0) * iy) + 3] = 0.0;
    }
    if (1 <= n - 2) {
      h[(n + h.size(0) * (n - 3)) - 1] = 0.0;
    }
    itmax = 30 * static_cast<int>(std::fmax(10.0, static_cast<double>(n)));
    SMLNUM = 2.2250738585072014E-308 *
             (static_cast<double>(n) / 2.2204460492503131E-16);
    i = n - 1;
    exitg1 = false;
    while ((!exitg1) && (i + 1 >= 1)) {
      int L;
      int hoffset;
      int its;
      int k;
      int knt;
      int nr;
      boolean_T exitg2;
      boolean_T goto150;
      L = 1;
      goto150 = false;
      its = 0;
      exitg2 = false;
      while ((!exitg2) && (its <= itmax)) {
        boolean_T exitg3;
        k = i;
        exitg3 = false;
        while ((!exitg3) && (k + 1 > L)) {
          ba = std::abs(h[k + h.size(0) * (k - 1)]);
          if (ba <= SMLNUM) {
            exitg3 = true;
          } else {
            bb = std::abs(h[k + h.size(0) * k]);
            tst = std::abs(h[(k + h.size(0) * (k - 1)) - 1]) + bb;
            if (tst == 0.0) {
              if (k - 1 >= 1) {
                tst = std::abs(h[(k + h.size(0) * (k - 2)) - 1]);
              }
              if (k + 2 <= n) {
                tst += std::abs(h[(k + h.size(0) * k) + 1]);
              }
            }
            if (ba <= 2.2204460492503131E-16 * tst) {
              tst = std::abs(h[(k + h.size(0) * k) - 1]);
              if (ba > tst) {
                ab = ba;
                ba = tst;
              } else {
                ab = tst;
              }
              tst = std::abs(h[(k + h.size(0) * (k - 1)) - 1] -
                             h[k + h.size(0) * k]);
              if (bb > tst) {
                aa = bb;
                bb = tst;
              } else {
                aa = tst;
              }
              s = aa + ab;
              if (ba * (ab / s) <=
                  std::fmax(SMLNUM, 2.2204460492503131E-16 * (bb * (aa / s)))) {
                exitg3 = true;
              } else {
                k--;
              }
            } else {
              k--;
            }
          }
        }
        L = k + 1;
        if (k + 1 > 1) {
          h[k + h.size(0) * (k - 1)] = 0.0;
        }
        if (k + 1 >= i) {
          goto150 = true;
          exitg2 = true;
        } else {
          int m;
          if (its == 10) {
            s = std::abs(h[(k + h.size(0) * k) + 1]) +
                std::abs(h[(k + h.size(0) * (k + 1)) + 2]);
            tst = 0.75 * s + h[k + h.size(0) * k];
            aa = -0.4375 * s;
            ab = s;
            bb = tst;
          } else if (its == 20) {
            s = std::abs(h[i + h.size(0) * (i - 1)]) +
                std::abs(h[(i + h.size(0) * (i - 2)) - 1]);
            tst = 0.75 * s + h[i + h.size(0) * i];
            aa = -0.4375 * s;
            ab = s;
            bb = tst;
          } else {
            tst = h[(i + h.size(0) * (i - 1)) - 1];
            ab = h[i + h.size(0) * (i - 1)];
            aa = h[(i + h.size(0) * i) - 1];
            bb = h[i + h.size(0) * i];
          }
          s = ((std::abs(tst) + std::abs(aa)) + std::abs(ab)) + std::abs(bb);
          if (s == 0.0) {
            rt1r = 0.0;
            ab = 0.0;
            rt2r = 0.0;
            aa = 0.0;
          } else {
            tst /= s;
            ab /= s;
            aa /= s;
            bb /= s;
            ba = (tst + bb) / 2.0;
            tst = (tst - ba) * (bb - ba) - aa * ab;
            ab = std::sqrt(std::abs(tst));
            if (tst >= 0.0) {
              rt1r = ba * s;
              rt2r = rt1r;
              ab *= s;
              aa = -ab;
            } else {
              rt1r = ba + ab;
              rt2r = ba - ab;
              if (std::abs(rt1r - bb) <= std::abs(rt2r - bb)) {
                rt1r *= s;
                rt2r = rt1r;
              } else {
                rt2r *= s;
                rt1r = rt2r;
              }
              ab = 0.0;
              aa = 0.0;
            }
          }
          m = i - 1;
          exitg3 = false;
          while ((!exitg3) && (m >= k + 1)) {
            tst = h[m + h.size(0) * (m - 1)];
            ba = h[(m + h.size(0) * (m - 1)) - 1];
            bb = ba - rt2r;
            s = (std::abs(bb) + std::abs(aa)) + std::abs(tst);
            tst /= s;
            v[0] = (tst * h[(m + h.size(0) * m) - 1] + (ba - rt1r) * (bb / s)) -
                   ab * (aa / s);
            v[1] = tst * (((ba + h[m + h.size(0) * m]) - rt1r) - rt2r);
            v[2] = tst * h[(m + h.size(0) * m) + 1];
            s = (std::abs(v[0]) + std::abs(v[1])) + std::abs(v[2]);
            v[0] /= s;
            v[1] /= s;
            v[2] /= s;
            if ((m == k + 1) ||
                (std::abs(h[(m + h.size(0) * (m - 2)) - 1]) *
                     (std::abs(v[1]) + std::abs(v[2])) <=
                 2.2204460492503131E-16 * std::abs(v[0]) *
                     ((std::abs(h[(m + h.size(0) * (m - 2)) - 2]) +
                       std::abs(ba)) +
                      std::abs(h[m + h.size(0) * m])))) {
              exitg3 = true;
            } else {
              m--;
            }
          }
          for (int b_k{m}; b_k <= i; b_k++) {
            nr = (i - b_k) + 2;
            if (3 < nr) {
              nr = 3;
            }
            if (b_k > m) {
              hoffset = (b_k + ldh * (b_k - 2)) - 1;
              for (iy = 0; iy < nr; iy++) {
                v[iy] = h[iy + hoffset];
              }
            }
            ab = v[0];
            ba = 0.0;
            if (nr > 0) {
              tst = blas::xnrm2(nr - 1, v);
              if (tst != 0.0) {
                aa = rt_hypotd_snf(v[0], tst);
                if (v[0] >= 0.0) {
                  aa = -aa;
                }
                if (std::abs(aa) < 1.0020841800044864E-292) {
                  knt = -1;
                  do {
                    knt++;
                    for (iy = 2; iy <= nr; iy++) {
                      v[iy - 1] *= 9.9792015476736E+291;
                    }
                    aa *= 9.9792015476736E+291;
                    ab *= 9.9792015476736E+291;
                  } while (!(std::abs(aa) >= 1.0020841800044864E-292));
                  aa = rt_hypotd_snf(ab, blas::xnrm2(nr - 1, v));
                  if (ab >= 0.0) {
                    aa = -aa;
                  }
                  ba = (aa - ab) / aa;
                  tst = 1.0 / (ab - aa);
                  for (iy = 2; iy <= nr; iy++) {
                    v[iy - 1] *= tst;
                  }
                  for (iy = 0; iy <= knt; iy++) {
                    aa *= 1.0020841800044864E-292;
                  }
                  ab = aa;
                } else {
                  ba = (aa - v[0]) / aa;
                  tst = 1.0 / (v[0] - aa);
                  for (iy = 2; iy <= nr; iy++) {
                    v[iy - 1] *= tst;
                  }
                  ab = aa;
                }
              }
            }
            v[0] = ab;
            if (b_k > m) {
              h[(b_k + h.size(0) * (b_k - 2)) - 1] = ab;
              h[b_k + h.size(0) * (b_k - 2)] = 0.0;
              if (b_k < i) {
                h[(b_k + h.size(0) * (b_k - 2)) + 1] = 0.0;
              }
            } else if (m > k + 1) {
              h[(b_k + h.size(0) * (b_k - 2)) - 1] =
                  h[(b_k + h.size(0) * (b_k - 2)) - 1] * (1.0 - ba);
            }
            d = v[1];
            ab = ba * v[1];
            if (nr == 3) {
              s = v[2];
              tst = ba * v[2];
              for (iy = b_k; iy <= n; iy++) {
                aa = (h[(b_k + h.size(0) * (iy - 1)) - 1] +
                      d * h[b_k + h.size(0) * (iy - 1)]) +
                     s * h[(b_k + h.size(0) * (iy - 1)) + 1];
                h[(b_k + h.size(0) * (iy - 1)) - 1] =
                    h[(b_k + h.size(0) * (iy - 1)) - 1] - aa * ba;
                h[b_k + h.size(0) * (iy - 1)] =
                    h[b_k + h.size(0) * (iy - 1)] - aa * ab;
                h[(b_k + h.size(0) * (iy - 1)) + 1] =
                    h[(b_k + h.size(0) * (iy - 1)) + 1] - aa * tst;
              }
              if (b_k + 3 < i + 1) {
                hoffset = b_k + 2;
              } else {
                hoffset = i;
              }
              for (iy = 0; iy <= hoffset; iy++) {
                aa = (h[iy + h.size(0) * (b_k - 1)] +
                      d * h[iy + h.size(0) * b_k]) +
                     s * h[iy + h.size(0) * (b_k + 1)];
                h[iy + h.size(0) * (b_k - 1)] =
                    h[iy + h.size(0) * (b_k - 1)] - aa * ba;
                h[iy + h.size(0) * b_k] = h[iy + h.size(0) * b_k] - aa * ab;
                h[iy + h.size(0) * (b_k + 1)] =
                    h[iy + h.size(0) * (b_k + 1)] - aa * tst;
              }
            } else if (nr == 2) {
              for (iy = b_k; iy <= n; iy++) {
                tst = h[(b_k + h.size(0) * (iy - 1)) - 1];
                aa = tst + d * h[b_k + h.size(0) * (iy - 1)];
                h[(b_k + h.size(0) * (iy - 1)) - 1] = tst - aa * ba;
                h[b_k + h.size(0) * (iy - 1)] =
                    h[b_k + h.size(0) * (iy - 1)] - aa * ab;
              }
              for (iy = 0; iy <= i; iy++) {
                aa =
                    h[iy + h.size(0) * (b_k - 1)] + d * h[iy + h.size(0) * b_k];
                h[iy + h.size(0) * (b_k - 1)] =
                    h[iy + h.size(0) * (b_k - 1)] - aa * ba;
                h[iy + h.size(0) * b_k] = h[iy + h.size(0) * b_k] - aa * ab;
              }
            }
          }
          its++;
        }
      }
      if (!goto150) {
        info = i + 1;
        exitg1 = true;
      } else {
        if ((L != i + 1) && (L == i)) {
          d = h[(i + h.size(0) * i) - 1];
          s = h[i + h.size(0) * (i - 1)];
          tst = h[i + h.size(0) * i];
          xdlanv2(&h[(i + h.size(0) * (i - 1)) - 1], &d, &s, &tst, &ab, &aa,
                  &ba, &bb, &rt2r, &rt1r);
          h[(i + h.size(0) * i) - 1] = d;
          h[i + h.size(0) * (i - 1)] = s;
          h[i + h.size(0) * i] = tst;
          if (n > i + 1) {
            knt = (n - i) - 2;
            if (knt + 1 >= 1) {
              iy = i + (i + 1) * ldh;
              for (k = 0; k <= knt; k++) {
                hoffset = iy + k * ldh;
                nr = hoffset - 1;
                tst = rt2r * h[nr] + rt1r * h[hoffset];
                h[hoffset] = rt2r * h[hoffset] - rt1r * h[nr];
                h[nr] = tst;
              }
            }
          }
          if (i - 1 >= 1) {
            knt = (i - 1) * ldh;
            iy = i * ldh;
            for (k = 0; k <= i - 2; k++) {
              nr = iy + k;
              hoffset = knt + k;
              tst = rt2r * h[hoffset] + rt1r * h[nr];
              h[nr] = rt2r * h[nr] - rt1r * h[hoffset];
              h[hoffset] = tst;
            }
          }
        }
        i = L - 2;
      }
    }
  }
  return info;
}

static void qrpf(::coder::array<double, 2U> &A, int m, int n, double tau_data[],
                 int jpvt_data[])
{
  double vn1_data[1002];
  double vn2_data[1002];
  double work_data[1002];
  double smax;
  int ix;
  int j;
  int ma;
  int minmn;
  ma = A.size(0);
  if (m < n) {
    minmn = m;
  } else {
    minmn = n;
  }
  ix = A.size(1);
  if (0 <= ix - 1) {
    std::memset(&work_data[0], 0, ix * sizeof(double));
  }
  ix = A.size(1);
  if (0 <= ix - 1) {
    std::memset(&vn1_data[0], 0, ix * sizeof(double));
  }
  ix = A.size(1);
  if (0 <= ix - 1) {
    std::memset(&vn2_data[0], 0, ix * sizeof(double));
  }
  for (j = 0; j < n; j++) {
    smax = blas::xnrm2(m, A, j * ma + 1);
    vn1_data[j] = smax;
    vn2_data[j] = smax;
  }
  for (int i{0}; i < minmn; i++) {
    double s;
    int b_i;
    int ii;
    int ip1;
    int lastc;
    int lastv;
    int mmi;
    int nmi;
    int pvt;
    ip1 = i + 2;
    lastc = i * ma;
    ii = lastc + i;
    nmi = n - i;
    mmi = (m - i) - 1;
    if (nmi < 1) {
      ix = -1;
    } else {
      ix = 0;
      if (nmi > 1) {
        smax = std::abs(vn1_data[i]);
        for (lastv = 2; lastv <= nmi; lastv++) {
          s = std::abs(vn1_data[(i + lastv) - 1]);
          if (s > smax) {
            ix = lastv - 1;
            smax = s;
          }
        }
      }
    }
    pvt = i + ix;
    if (pvt + 1 != i + 1) {
      ix = pvt * ma;
      for (lastv = 0; lastv < m; lastv++) {
        j = ix + lastv;
        smax = A[j];
        b_i = lastc + lastv;
        A[j] = A[b_i];
        A[b_i] = smax;
      }
      ix = jpvt_data[pvt];
      jpvt_data[pvt] = jpvt_data[i];
      jpvt_data[i] = ix;
      vn1_data[pvt] = vn1_data[i];
      vn2_data[pvt] = vn2_data[i];
    }
    if (i + 1 < m) {
      smax = A[ii];
      tau_data[i] = xzlarfg(mmi + 1, &smax, A, ii + 2);
      A[ii] = smax;
    } else {
      tau_data[i] = 0.0;
    }
    if (i + 1 < n) {
      int ia;
      smax = A[ii];
      A[ii] = 1.0;
      pvt = (ii + ma) + 1;
      if (tau_data[i] != 0.0) {
        boolean_T exitg2;
        lastv = mmi + 1;
        ix = ii + mmi;
        while ((lastv > 0) && (A[ix] == 0.0)) {
          lastv--;
          ix--;
        }
        lastc = nmi - 1;
        exitg2 = false;
        while ((!exitg2) && (lastc > 0)) {
          int exitg1;
          ix = pvt + (lastc - 1) * ma;
          ia = ix;
          do {
            exitg1 = 0;
            if (ia <= (ix + lastv) - 1) {
              if (A[ia - 1] != 0.0) {
                exitg1 = 1;
              } else {
                ia++;
              }
            } else {
              lastc--;
              exitg1 = 2;
            }
          } while (exitg1 == 0);
          if (exitg1 == 1) {
            exitg2 = true;
          }
        }
      } else {
        lastv = 0;
        lastc = 0;
      }
      if (lastv > 0) {
        if (lastc != 0) {
          if (0 <= lastc - 1) {
            std::memset(&work_data[0], 0, lastc * sizeof(double));
          }
          j = 0;
          b_i = pvt + ma * (lastc - 1);
          for (nmi = pvt; ma < 0 ? nmi >= b_i : nmi <= b_i; nmi += ma) {
            s = 0.0;
            ix = (nmi + lastv) - 1;
            for (ia = nmi; ia <= ix; ia++) {
              s += A[ia - 1] * A[(ii + ia) - nmi];
            }
            work_data[j] += s;
            j++;
          }
        }
        blas::xgerc(lastv, lastc, -tau_data[i], ii + 1, work_data, A, pvt, ma);
      }
      A[ii] = smax;
    }
    for (j = ip1; j <= n; j++) {
      ix = i + (j - 1) * ma;
      smax = vn1_data[j - 1];
      if (smax != 0.0) {
        double temp2;
        s = std::abs(A[ix]) / smax;
        s = 1.0 - s * s;
        if (s < 0.0) {
          s = 0.0;
        }
        temp2 = smax / vn2_data[j - 1];
        temp2 = s * (temp2 * temp2);
        if (temp2 <= 1.4901161193847656E-8) {
          if (i + 1 < m) {
            smax = blas::xnrm2(mmi, A, ix + 2);
            vn1_data[j - 1] = smax;
            vn2_data[j - 1] = smax;
          } else {
            vn1_data[j - 1] = 0.0;
            vn2_data[j - 1] = 0.0;
          }
        } else {
          vn1_data[j - 1] = smax * std::sqrt(s);
        }
      }
    }
  }
}

static void xdlanv2(double *a, double *b, double *c, double *d, double *rt1r,
                    double *rt1i, double *rt2r, double *rt2i, double *cs,
                    double *sn)
{
  if (*c == 0.0) {
    *cs = 1.0;
    *sn = 0.0;
  } else if (*b == 0.0) {
    double bcmax;
    *cs = 0.0;
    *sn = 1.0;
    bcmax = *d;
    *d = *a;
    *a = bcmax;
    *b = -*c;
    *c = 0.0;
  } else {
    double tau;
    tau = *a - *d;
    if ((tau == 0.0) && ((*b < 0.0) != (*c < 0.0))) {
      *cs = 1.0;
      *sn = 0.0;
    } else {
      double bcmax;
      double bcmis;
      double p;
      double scale;
      double z;
      int b_b;
      int b_c;
      p = 0.5 * tau;
      bcmis = std::abs(*b);
      scale = std::abs(*c);
      bcmax = std::fmax(bcmis, scale);
      if (!(*b < 0.0)) {
        b_b = 1;
      } else {
        b_b = -1;
      }
      if (!(*c < 0.0)) {
        b_c = 1;
      } else {
        b_c = -1;
      }
      bcmis = std::fmin(bcmis, scale) * static_cast<double>(b_b) *
              static_cast<double>(b_c);
      scale = std::fmax(std::abs(p), bcmax);
      z = p / scale * p + bcmax / scale * bcmis;
      if (z >= 8.8817841970012523E-16) {
        *a = std::sqrt(scale) * std::sqrt(z);
        if (p < 0.0) {
          *a = -*a;
        }
        z = p + *a;
        *a = *d + z;
        *d -= bcmax / z * bcmis;
        tau = rt_hypotd_snf(*c, z);
        *cs = z / tau;
        *sn = *c / tau;
        *b -= *c;
        *c = 0.0;
      } else {
        bcmis = *b + *c;
        tau = rt_hypotd_snf(bcmis, tau);
        *cs = std::sqrt(0.5 * (std::abs(bcmis) / tau + 1.0));
        if (!(bcmis < 0.0)) {
          b_b = 1;
        } else {
          b_b = -1;
        }
        *sn = -(p / (tau * *cs)) * static_cast<double>(b_b);
        bcmax = *a * *cs + *b * *sn;
        scale = -*a * *sn + *b * *cs;
        z = *c * *cs + *d * *sn;
        bcmis = -*c * *sn + *d * *cs;
        *b = scale * *cs + bcmis * *sn;
        *c = -bcmax * *sn + z * *cs;
        bcmax = 0.5 * ((bcmax * *cs + z * *sn) + (-scale * *sn + bcmis * *cs));
        *a = bcmax;
        *d = bcmax;
        if (*c != 0.0) {
          if (*b != 0.0) {
            if ((*b < 0.0) == (*c < 0.0)) {
              bcmis = std::sqrt(std::abs(*b));
              z = std::sqrt(std::abs(*c));
              *a = bcmis * z;
              if (!(*c < 0.0)) {
                p = *a;
              } else {
                p = -*a;
              }
              tau = 1.0 / std::sqrt(std::abs(*b + *c));
              *a = bcmax + p;
              *d = bcmax - p;
              *b -= *c;
              *c = 0.0;
              scale = bcmis * tau;
              bcmis = z * tau;
              bcmax = *cs * scale - *sn * bcmis;
              *sn = *cs * bcmis + *sn * scale;
              *cs = bcmax;
            }
          } else {
            *b = -*c;
            *c = 0.0;
            bcmax = *cs;
            *cs = -*sn;
            *sn = bcmax;
          }
        }
      }
    }
  }
  *rt1r = *a;
  *rt2r = *d;
  if (*c == 0.0) {
    *rt1i = 0.0;
    *rt2i = 0.0;
  } else {
    *rt1i = std::sqrt(std::abs(*b)) * std::sqrt(std::abs(*c));
    *rt2i = -*rt1i;
  }
}

static void xzgeev(const ::coder::array<double, 2U> &A, int *info,
                   creal_T alpha1_data[], int *alpha1_size,
                   creal_T beta1_data[], int *beta1_size)
{
  array<creal_T, 2U> At;
  creal_T s;
  double absxk;
  int rscale_data[1002];
  int ihi;
  int ilo;
  int jcol;
  int n;
  At.set_size(A.size(0), A.size(1));
  n = A.size(0) * A.size(1);
  for (jcol = 0; jcol < n; jcol++) {
    At[jcol].re = A[jcol];
    At[jcol].im = 0.0;
  }
  *info = 0;
  *alpha1_size = At.size(0);
  n = At.size(0);
  if (0 <= n - 1) {
    std::memset(&alpha1_data[0], 0, n * sizeof(creal_T));
  }
  *beta1_size = At.size(0);
  n = At.size(0);
  if (0 <= n - 1) {
    std::memset(&beta1_data[0], 0, n * sizeof(creal_T));
  }
  if ((At.size(0) != 0) && (At.size(1) != 0)) {
    double anrm;
    boolean_T exitg1;
    anrm = 0.0;
    n = 0;
    exitg1 = false;
    while ((!exitg1) && (n <= At.size(0) * At.size(1) - 1)) {
      absxk = rt_hypotd_snf(At[n].re, At[n].im);
      if (std::isnan(absxk)) {
        anrm = rtNaN;
        exitg1 = true;
      } else {
        if (absxk > anrm) {
          anrm = absxk;
        }
        n++;
      }
    }
    if (std::isinf(anrm) || std::isnan(anrm)) {
      *alpha1_size = At.size(0);
      n = At.size(0);
      for (jcol = 0; jcol < n; jcol++) {
        alpha1_data[jcol].re = rtNaN;
        alpha1_data[jcol].im = 0.0;
      }
      *beta1_size = At.size(0);
      n = At.size(0);
      for (jcol = 0; jcol < n; jcol++) {
        beta1_data[jcol].re = rtNaN;
        beta1_data[jcol].im = 0.0;
      }
    } else {
      double a;
      double anrmto;
      double cto1;
      double ctoc;
      double stemp_im;
      boolean_T guard1{false};
      boolean_T ilascl;
      boolean_T notdone;
      ilascl = false;
      anrmto = anrm;
      guard1 = false;
      if ((anrm > 0.0) && (anrm < 6.7178761075670888E-139)) {
        anrmto = 6.7178761075670888E-139;
        ilascl = true;
        guard1 = true;
      } else if (anrm > 1.4885657073574029E+138) {
        anrmto = 1.4885657073574029E+138;
        ilascl = true;
        guard1 = true;
      }
      if (guard1) {
        absxk = anrm;
        ctoc = anrmto;
        notdone = true;
        while (notdone) {
          stemp_im = absxk * 2.0041683600089728E-292;
          cto1 = ctoc / 4.9896007738368E+291;
          if ((stemp_im > ctoc) && (ctoc != 0.0)) {
            a = 2.0041683600089728E-292;
            absxk = stemp_im;
          } else if (cto1 > absxk) {
            a = 4.9896007738368E+291;
            ctoc = cto1;
          } else {
            a = ctoc / absxk;
            notdone = false;
          }
          n = At.size(0) * At.size(1);
          for (jcol = 0; jcol < n; jcol++) {
            At[jcol].re = a * At[jcol].re;
            At[jcol].im = a * At[jcol].im;
          }
        }
      }
      xzggbal(At, &ilo, &ihi, rscale_data, &n);
      n = At.size(0);
      if ((At.size(0) > 1) && (ihi >= ilo + 2)) {
        for (jcol = ilo - 1; jcol + 1 < ihi - 1; jcol++) {
          int jcolp1;
          jcolp1 = jcol + 2;
          for (int jrow{ihi - 1}; jrow + 1 > jcol + 2; jrow--) {
            int j;
            xzlartg(At[(jrow + At.size(0) * jcol) - 1],
                    At[jrow + At.size(0) * jcol], &absxk, &s,
                    &At[(jrow + At.size(0) * jcol) - 1]);
            At[jrow + At.size(0) * jcol].re = 0.0;
            At[jrow + At.size(0) * jcol].im = 0.0;
            for (j = jcolp1; j <= n; j++) {
              ctoc = absxk * At[(jrow + At.size(0) * (j - 1)) - 1].re +
                     (s.re * At[jrow + At.size(0) * (j - 1)].re -
                      s.im * At[jrow + At.size(0) * (j - 1)].im);
              stemp_im = absxk * At[(jrow + At.size(0) * (j - 1)) - 1].im +
                         (s.re * At[jrow + At.size(0) * (j - 1)].im +
                          s.im * At[jrow + At.size(0) * (j - 1)].re);
              cto1 = At[(jrow + At.size(0) * (j - 1)) - 1].im;
              a = At[(jrow + At.size(0) * (j - 1)) - 1].re;
              At[jrow + At.size(0) * (j - 1)].re =
                  absxk * At[jrow + At.size(0) * (j - 1)].re -
                  (s.re * At[(jrow + At.size(0) * (j - 1)) - 1].re +
                   s.im * At[(jrow + At.size(0) * (j - 1)) - 1].im);
              At[jrow + At.size(0) * (j - 1)].im =
                  absxk * At[jrow + At.size(0) * (j - 1)].im -
                  (s.re * cto1 - s.im * a);
              At[(jrow + At.size(0) * (j - 1)) - 1].re = ctoc;
              At[(jrow + At.size(0) * (j - 1)) - 1].im = stemp_im;
            }
            s.re = -s.re;
            s.im = -s.im;
            for (j = 1; j <= ihi; j++) {
              ctoc = absxk * At[(j + At.size(0) * jrow) - 1].re +
                     (s.re * At[(j + At.size(0) * (jrow - 1)) - 1].re -
                      s.im * At[(j + At.size(0) * (jrow - 1)) - 1].im);
              stemp_im = absxk * At[(j + At.size(0) * jrow) - 1].im +
                         (s.re * At[(j + At.size(0) * (jrow - 1)) - 1].im +
                          s.im * At[(j + At.size(0) * (jrow - 1)) - 1].re);
              cto1 = At[(j + At.size(0) * jrow) - 1].im;
              a = At[(j + At.size(0) * jrow) - 1].re;
              At[(j + At.size(0) * (jrow - 1)) - 1].re =
                  absxk * At[(j + At.size(0) * (jrow - 1)) - 1].re -
                  (s.re * At[(j + At.size(0) * jrow) - 1].re +
                   s.im * At[(j + At.size(0) * jrow) - 1].im);
              At[(j + At.size(0) * (jrow - 1)) - 1].im =
                  absxk * At[(j + At.size(0) * (jrow - 1)) - 1].im -
                  (s.re * cto1 - s.im * a);
              At[(j + At.size(0) * jrow) - 1].re = ctoc;
              At[(j + At.size(0) * jrow) - 1].im = stemp_im;
            }
          }
        }
      }
      xzhgeqz(At, ilo, ihi, info, alpha1_data, alpha1_size, beta1_data,
              beta1_size);
      if ((*info == 0) && ilascl) {
        notdone = true;
        while (notdone) {
          stemp_im = anrmto * 2.0041683600089728E-292;
          cto1 = anrm / 4.9896007738368E+291;
          if ((stemp_im > anrm) && (anrm != 0.0)) {
            a = 2.0041683600089728E-292;
            anrmto = stemp_im;
          } else if (cto1 > anrmto) {
            a = 4.9896007738368E+291;
            anrm = cto1;
          } else {
            a = anrm / anrmto;
            notdone = false;
          }
          for (jcol = 0; jcol < *alpha1_size; jcol++) {
            alpha1_data[jcol].re *= a;
            alpha1_data[jcol].im *= a;
          }
        }
      }
    }
  }
}

static void xzggbal(::coder::array<creal_T, 2U> &A, int *ilo, int *ihi,
                    int rscale_data[], int *rscale_size)
{
  int ii;
  int nzcount;
  *rscale_size = A.size(0);
  nzcount = A.size(0);
  for (ii = 0; ii < nzcount; ii++) {
    rscale_data[ii] = 1;
  }
  *ilo = 1;
  *ihi = A.size(0);
  if (A.size(0) <= 1) {
    *ihi = 1;
  } else {
    double atmp_im;
    double atmp_re;
    int exitg2;
    int i;
    int j;
    int jj;
    boolean_T exitg3;
    boolean_T exitg4;
    boolean_T found;
    do {
      exitg2 = 0;
      i = 0;
      j = 0;
      found = false;
      ii = *ihi;
      exitg3 = false;
      while ((!exitg3) && (ii > 0)) {
        nzcount = 0;
        i = ii;
        j = *ihi;
        jj = 0;
        exitg4 = false;
        while ((!exitg4) && (jj <= *ihi - 1)) {
          if ((A[(ii + A.size(0) * jj) - 1].re != 0.0) ||
              (A[(ii + A.size(0) * jj) - 1].im != 0.0) || (ii == jj + 1)) {
            if (nzcount == 0) {
              j = jj + 1;
              nzcount = 1;
              jj++;
            } else {
              nzcount = 2;
              exitg4 = true;
            }
          } else {
            jj++;
          }
        }
        if (nzcount < 2) {
          found = true;
          exitg3 = true;
        } else {
          ii--;
        }
      }
      if (!found) {
        exitg2 = 2;
      } else {
        nzcount = A.size(0);
        if (i != *ihi) {
          for (ii = 1; ii <= nzcount; ii++) {
            atmp_re = A[(i + A.size(0) * (ii - 1)) - 1].re;
            atmp_im = A[(i + A.size(0) * (ii - 1)) - 1].im;
            A[(i + A.size(0) * (ii - 1)) - 1] =
                A[(*ihi + A.size(0) * (ii - 1)) - 1];
            A[(*ihi + A.size(0) * (ii - 1)) - 1].re = atmp_re;
            A[(*ihi + A.size(0) * (ii - 1)) - 1].im = atmp_im;
          }
        }
        if (j != *ihi) {
          for (ii = 0; ii < *ihi; ii++) {
            atmp_re = A[ii + A.size(0) * (j - 1)].re;
            atmp_im = A[ii + A.size(0) * (j - 1)].im;
            A[ii + A.size(0) * (j - 1)] = A[ii + A.size(0) * (*ihi - 1)];
            A[ii + A.size(0) * (*ihi - 1)].re = atmp_re;
            A[ii + A.size(0) * (*ihi - 1)].im = atmp_im;
          }
        }
        rscale_data[*ihi - 1] = j;
        (*ihi)--;
        if (*ihi == 1) {
          rscale_data[0] = 1;
          exitg2 = 1;
        }
      }
    } while (exitg2 == 0);
    if (exitg2 != 1) {
      int exitg1;
      do {
        exitg1 = 0;
        i = 0;
        j = 0;
        found = false;
        jj = *ilo;
        exitg3 = false;
        while ((!exitg3) && (jj <= *ihi)) {
          nzcount = 0;
          i = *ihi;
          j = jj;
          ii = *ilo;
          exitg4 = false;
          while ((!exitg4) && (ii <= *ihi)) {
            if ((A[(ii + A.size(0) * (jj - 1)) - 1].re != 0.0) ||
                (A[(ii + A.size(0) * (jj - 1)) - 1].im != 0.0) || (ii == jj)) {
              if (nzcount == 0) {
                i = ii;
                nzcount = 1;
                ii++;
              } else {
                nzcount = 2;
                exitg4 = true;
              }
            } else {
              ii++;
            }
          }
          if (nzcount < 2) {
            found = true;
            exitg3 = true;
          } else {
            jj++;
          }
        }
        if (!found) {
          exitg1 = 1;
        } else {
          nzcount = A.size(0);
          if (i != *ilo) {
            for (ii = *ilo; ii <= nzcount; ii++) {
              atmp_re = A[(i + A.size(0) * (ii - 1)) - 1].re;
              atmp_im = A[(i + A.size(0) * (ii - 1)) - 1].im;
              A[(i + A.size(0) * (ii - 1)) - 1] =
                  A[(*ilo + A.size(0) * (ii - 1)) - 1];
              A[(*ilo + A.size(0) * (ii - 1)) - 1].re = atmp_re;
              A[(*ilo + A.size(0) * (ii - 1)) - 1].im = atmp_im;
            }
          }
          if (j != *ilo) {
            for (ii = 0; ii < *ihi; ii++) {
              atmp_re = A[ii + A.size(0) * (j - 1)].re;
              atmp_im = A[ii + A.size(0) * (j - 1)].im;
              A[ii + A.size(0) * (j - 1)] = A[ii + A.size(0) * (*ilo - 1)];
              A[ii + A.size(0) * (*ilo - 1)].re = atmp_re;
              A[ii + A.size(0) * (*ilo - 1)].im = atmp_im;
            }
          }
          rscale_data[*ilo - 1] = j;
          (*ilo)++;
          if (*ilo == *ihi) {
            rscale_data[*ilo - 1] = *ilo;
            exitg1 = 1;
          }
        }
      } while (exitg1 == 0);
    }
  }
}

static void xzhgeqz(const ::coder::array<creal_T, 2U> &A, int ilo, int ihi,
                    int *info, creal_T alpha1_data[], int *alpha1_size,
                    creal_T beta1_data[], int *beta1_size)
{
  array<creal_T, 2U> b_A;
  creal_T b_ascale;
  creal_T ctemp;
  creal_T shift;
  double anorm;
  double ascale;
  double b_atol;
  double bscale;
  double colscale;
  double colssq;
  double eshift_im;
  double eshift_re;
  double scale;
  double ssq;
  double t;
  int col;
  int ilast;
  int istart;
  int j;
  int jp1;
  int n;
  int nm1;
  boolean_T failed;
  boolean_T guard1{false};
  boolean_T guard2{false};
  b_A.set_size(A.size(0), A.size(1));
  jp1 = A.size(0) * A.size(1);
  for (istart = 0; istart < jp1; istart++) {
    b_A[istart] = A[istart];
  }
  *info = 0;
  if ((A.size(0) == 1) && (A.size(1) == 1)) {
    ihi = 1;
  }
  n = A.size(0);
  *alpha1_size = A.size(0);
  jp1 = A.size(0);
  if (0 <= jp1 - 1) {
    std::memset(&alpha1_data[0], 0, jp1 * sizeof(creal_T));
  }
  *beta1_size = A.size(0);
  jp1 = A.size(0);
  for (istart = 0; istart < jp1; istart++) {
    beta1_data[istart].re = 1.0;
    beta1_data[istart].im = 0.0;
  }
  eshift_re = 0.0;
  eshift_im = 0.0;
  ctemp.re = 0.0;
  ctemp.im = 0.0;
  anorm = 0.0;
  if (ilo <= ihi) {
    scale = 3.3121686421112381E-170;
    ssq = 0.0;
    nm1 = ihi - ilo;
    for (j = 0; j <= nm1; j++) {
      colscale = 3.3121686421112381E-170;
      colssq = 0.0;
      col = (ilo + j) - 1;
      jp1 = j + 1;
      if (jp1 >= nm1) {
        jp1 = nm1;
      }
      istart = ilo + jp1;
      for (jp1 = ilo; jp1 <= istart; jp1++) {
        anorm = std::abs(A[(jp1 + A.size(0) * col) - 1].re);
        if (anorm > colscale) {
          t = colscale / anorm;
          colssq = colssq * t * t + 1.0;
          colscale = anorm;
        } else {
          t = anorm / colscale;
          colssq += t * t;
        }
        anorm = std::abs(A[(jp1 + A.size(0) * col) - 1].im);
        if (anorm > colscale) {
          t = colscale / anorm;
          colssq = colssq * t * t + 1.0;
          colscale = anorm;
        } else {
          t = anorm / colscale;
          colssq += t * t;
        }
      }
      if (scale >= colscale) {
        t = colscale / scale;
        ssq += t * t * colssq;
      } else {
        t = scale / colscale;
        ssq = colssq + t * t * ssq;
        scale = colscale;
      }
    }
    anorm = scale * std::sqrt(ssq);
  }
  t = 2.2204460492503131E-16 * anorm;
  b_atol = 2.2250738585072014E-308;
  if (t > 2.2250738585072014E-308) {
    b_atol = t;
  }
  t = 2.2250738585072014E-308;
  if (anorm > 2.2250738585072014E-308) {
    t = anorm;
  }
  ascale = 1.0 / t;
  bscale = 1.0 / std::sqrt(static_cast<double>(A.size(0)));
  failed = true;
  istart = ihi + 1;
  for (j = istart; j <= n; j++) {
    alpha1_data[j - 1] = A[(j + A.size(0) * (j - 1)) - 1];
  }
  guard1 = false;
  guard2 = false;
  if (ihi >= ilo) {
    int iiter;
    int ilastm;
    int ilastm1;
    int jiter;
    boolean_T goto60;
    boolean_T goto70;
    boolean_T goto90;
    n = ilo;
    istart = ilo;
    ilast = ihi - 1;
    ilastm1 = ihi - 2;
    ilastm = ihi;
    iiter = 0;
    goto60 = false;
    goto70 = false;
    goto90 = false;
    jiter = 0;
    int exitg1;
    do {
      exitg1 = 0;
      if (jiter <= 30 * ((ihi - ilo) + 1) - 1) {
        boolean_T b_guard1{false};
        boolean_T exitg2;
        b_guard1 = false;
        if (ilast + 1 == ilo) {
          goto60 = true;
          b_guard1 = true;
        } else if (std::abs(b_A[ilast + b_A.size(0) * ilastm1].re) +
                       std::abs(b_A[ilast + b_A.size(0) * ilastm1].im) <=
                   b_atol) {
          b_A[ilast + b_A.size(0) * ilastm1].re = 0.0;
          b_A[ilast + b_A.size(0) * ilastm1].im = 0.0;
          goto60 = true;
          b_guard1 = true;
        } else {
          boolean_T guard3{false};
          j = ilastm1;
          guard3 = false;
          exitg2 = false;
          while ((!exitg2) && (j + 1 >= ilo)) {
            if (j + 1 == ilo) {
              guard3 = true;
              exitg2 = true;
            } else if (std::abs(b_A[j + b_A.size(0) * (j - 1)].re) +
                           std::abs(b_A[j + b_A.size(0) * (j - 1)].im) <=
                       b_atol) {
              b_A[j + b_A.size(0) * (j - 1)].re = 0.0;
              b_A[j + b_A.size(0) * (j - 1)].im = 0.0;
              guard3 = true;
              exitg2 = true;
            } else {
              j--;
              guard3 = false;
            }
          }
          if (guard3) {
            n = j + 1;
            goto70 = true;
          }
          if (goto70) {
            b_guard1 = true;
          } else {
            for (istart = 0; istart < *alpha1_size; istart++) {
              alpha1_data[istart].re = rtNaN;
              alpha1_data[istart].im = 0.0;
            }
            for (istart = 0; istart < *beta1_size; istart++) {
              beta1_data[istart].re = rtNaN;
              beta1_data[istart].im = 0.0;
            }
            *info = 1;
            exitg1 = 1;
          }
        }
        if (b_guard1) {
          if (goto60) {
            goto60 = false;
            alpha1_data[ilast] = b_A[ilast + b_A.size(0) * ilast];
            ilast = ilastm1;
            ilastm1--;
            if (ilast + 1 < ilo) {
              failed = false;
              guard2 = true;
              exitg1 = 1;
            } else {
              iiter = 0;
              eshift_re = 0.0;
              eshift_im = 0.0;
              ilastm = ilast + 1;
              jiter++;
            }
          } else {
            if (goto70) {
              double ad22_im;
              double ad22_re;
              goto70 = false;
              iiter++;
              if (iiter - iiter / 10 * 10 != 0) {
                double t1_im;
                double t1_im_tmp;
                double t1_re;
                anorm = ascale * b_A[ilastm1 + b_A.size(0) * ilastm1].re;
                t = ascale * b_A[ilastm1 + b_A.size(0) * ilastm1].im;
                if (t == 0.0) {
                  shift.re = anorm / bscale;
                  shift.im = 0.0;
                } else if (anorm == 0.0) {
                  shift.re = 0.0;
                  shift.im = t / bscale;
                } else {
                  shift.re = anorm / bscale;
                  shift.im = t / bscale;
                }
                anorm = ascale * b_A[ilast + b_A.size(0) * ilast].re;
                t = ascale * b_A[ilast + b_A.size(0) * ilast].im;
                if (t == 0.0) {
                  ad22_re = anorm / bscale;
                  ad22_im = 0.0;
                } else if (anorm == 0.0) {
                  ad22_re = 0.0;
                  ad22_im = t / bscale;
                } else {
                  ad22_re = anorm / bscale;
                  ad22_im = t / bscale;
                }
                t1_re = 0.5 * (shift.re + ad22_re);
                t1_im = 0.5 * (shift.im + ad22_im);
                t1_im_tmp = t1_re * t1_im;
                anorm = ascale * b_A[ilastm1 + b_A.size(0) * ilast].re;
                t = ascale * b_A[ilastm1 + b_A.size(0) * ilast].im;
                if (t == 0.0) {
                  colscale = anorm / bscale;
                  colssq = 0.0;
                } else if (anorm == 0.0) {
                  colscale = 0.0;
                  colssq = t / bscale;
                } else {
                  colscale = anorm / bscale;
                  colssq = t / bscale;
                }
                anorm = ascale * b_A[ilast + b_A.size(0) * ilastm1].re;
                t = ascale * b_A[ilast + b_A.size(0) * ilastm1].im;
                if (t == 0.0) {
                  ssq = anorm / bscale;
                  anorm = 0.0;
                } else if (anorm == 0.0) {
                  ssq = 0.0;
                  anorm = t / bscale;
                } else {
                  ssq = anorm / bscale;
                  anorm = t / bscale;
                }
                t = shift.re * ad22_re - shift.im * ad22_im;
                scale = shift.re * ad22_im + shift.im * ad22_re;
                shift.re = ((t1_re * t1_re - t1_im * t1_im) +
                            (colscale * ssq - colssq * anorm)) -
                           t;
                shift.im = ((t1_im_tmp + t1_im_tmp) +
                            (colscale * anorm + colssq * ssq)) -
                           scale;
                b_sqrt(&shift);
                if ((t1_re - ad22_re) * shift.re +
                        (t1_im - ad22_im) * shift.im <=
                    0.0) {
                  shift.re += t1_re;
                  shift.im += t1_im;
                } else {
                  shift.re = t1_re - shift.re;
                  shift.im = t1_im - shift.im;
                }
              } else {
                anorm = ascale * b_A[ilast + b_A.size(0) * ilastm1].re;
                t = ascale * b_A[ilast + b_A.size(0) * ilastm1].im;
                if (t == 0.0) {
                  colscale = anorm / bscale;
                  colssq = 0.0;
                } else if (anorm == 0.0) {
                  colscale = 0.0;
                  colssq = t / bscale;
                } else {
                  colscale = anorm / bscale;
                  colssq = t / bscale;
                }
                eshift_re += colscale;
                eshift_im += colssq;
                shift.re = eshift_re;
                shift.im = eshift_im;
              }
              j = ilastm1;
              jp1 = ilastm1 + 1;
              exitg2 = false;
              while ((!exitg2) && (j + 1 > n)) {
                istart = j + 1;
                ctemp.re =
                    ascale * b_A[j + b_A.size(0) * j].re - shift.re * bscale;
                ctemp.im =
                    ascale * b_A[j + b_A.size(0) * j].im - shift.im * bscale;
                anorm = std::abs(ctemp.re) + std::abs(ctemp.im);
                t = ascale * (std::abs(b_A[jp1 + b_A.size(0) * j].re) +
                              std::abs(b_A[jp1 + b_A.size(0) * j].im));
                scale = anorm;
                if (t > anorm) {
                  scale = t;
                }
                if ((scale < 1.0) && (scale != 0.0)) {
                  anorm /= scale;
                  t /= scale;
                }
                if ((std::abs(b_A[j + b_A.size(0) * (j - 1)].re) +
                     std::abs(b_A[j + b_A.size(0) * (j - 1)].im)) *
                        t <=
                    anorm * b_atol) {
                  goto90 = true;
                  exitg2 = true;
                } else {
                  jp1 = j;
                  j--;
                }
              }
              if (!goto90) {
                istart = n;
                ctemp.re = ascale * b_A[(n + b_A.size(0) * (n - 1)) - 1].re -
                           shift.re * bscale;
                ctemp.im = ascale * b_A[(n + b_A.size(0) * (n - 1)) - 1].im -
                           shift.im * bscale;
              }
              goto90 = false;
              b_ascale.re =
                  ascale * b_A[istart + b_A.size(0) * (istart - 1)].re;
              b_ascale.im =
                  ascale * b_A[istart + b_A.size(0) * (istart - 1)].im;
              xzlartg(ctemp, b_ascale, &anorm, &shift);
              j = istart;
              nm1 = istart - 2;
              while (j < ilast + 1) {
                if (j > istart) {
                  xzlartg(b_A[(j + b_A.size(0) * nm1) - 1],
                          b_A[j + b_A.size(0) * nm1], &anorm, &shift,
                          &b_A[(j + b_A.size(0) * nm1) - 1]);
                  b_A[j + b_A.size(0) * nm1].re = 0.0;
                  b_A[j + b_A.size(0) * nm1].im = 0.0;
                }
                for (nm1 = j; nm1 <= ilastm; nm1++) {
                  ad22_re = anorm * b_A[(j + b_A.size(0) * (nm1 - 1)) - 1].re +
                            (shift.re * b_A[j + b_A.size(0) * (nm1 - 1)].re -
                             shift.im * b_A[j + b_A.size(0) * (nm1 - 1)].im);
                  ad22_im = anorm * b_A[(j + b_A.size(0) * (nm1 - 1)) - 1].im +
                            (shift.re * b_A[j + b_A.size(0) * (nm1 - 1)].im +
                             shift.im * b_A[j + b_A.size(0) * (nm1 - 1)].re);
                  t = b_A[(j + b_A.size(0) * (nm1 - 1)) - 1].re;
                  b_A[j + b_A.size(0) * (nm1 - 1)].re =
                      anorm * b_A[j + b_A.size(0) * (nm1 - 1)].re -
                      (shift.re * b_A[(j + b_A.size(0) * (nm1 - 1)) - 1].re +
                       shift.im * b_A[(j + b_A.size(0) * (nm1 - 1)) - 1].im);
                  b_A[j + b_A.size(0) * (nm1 - 1)].im =
                      anorm * b_A[j + b_A.size(0) * (nm1 - 1)].im -
                      (shift.re * b_A[(j + b_A.size(0) * (nm1 - 1)) - 1].im -
                       shift.im * t);
                  b_A[(j + b_A.size(0) * (nm1 - 1)) - 1].re = ad22_re;
                  b_A[(j + b_A.size(0) * (nm1 - 1)) - 1].im = ad22_im;
                }
                shift.re = -shift.re;
                shift.im = -shift.im;
                nm1 = j;
                if (ilast + 1 < j + 2) {
                  nm1 = ilast - 1;
                }
                for (col = n; col <= nm1 + 2; col++) {
                  ad22_re =
                      anorm * b_A[(col + b_A.size(0) * j) - 1].re +
                      (shift.re * b_A[(col + b_A.size(0) * (j - 1)) - 1].re -
                       shift.im * b_A[(col + b_A.size(0) * (j - 1)) - 1].im);
                  ad22_im =
                      anorm * b_A[(col + b_A.size(0) * j) - 1].im +
                      (shift.re * b_A[(col + b_A.size(0) * (j - 1)) - 1].im +
                       shift.im * b_A[(col + b_A.size(0) * (j - 1)) - 1].re);
                  t = b_A[(col + b_A.size(0) * j) - 1].re;
                  b_A[(col + b_A.size(0) * (j - 1)) - 1].re =
                      anorm * b_A[(col + b_A.size(0) * (j - 1)) - 1].re -
                      (shift.re * b_A[(col + b_A.size(0) * j) - 1].re +
                       shift.im * b_A[(col + b_A.size(0) * j) - 1].im);
                  b_A[(col + b_A.size(0) * (j - 1)) - 1].im =
                      anorm * b_A[(col + b_A.size(0) * (j - 1)) - 1].im -
                      (shift.re * b_A[(col + b_A.size(0) * j) - 1].im -
                       shift.im * t);
                  b_A[(col + b_A.size(0) * j) - 1].re = ad22_re;
                  b_A[(col + b_A.size(0) * j) - 1].im = ad22_im;
                }
                nm1 = j - 1;
                j++;
              }
            }
            jiter++;
          }
        }
      } else {
        guard2 = true;
        exitg1 = 1;
      }
    } while (exitg1 == 0);
  } else {
    guard1 = true;
  }
  if (guard2) {
    if (failed) {
      *info = ilast + 1;
      for (jp1 = 0; jp1 <= ilast; jp1++) {
        alpha1_data[jp1].re = rtNaN;
        alpha1_data[jp1].im = 0.0;
        beta1_data[jp1].re = rtNaN;
        beta1_data[jp1].im = 0.0;
      }
    } else {
      guard1 = true;
    }
  }
  if (guard1) {
    for (j = 0; j <= ilo - 2; j++) {
      alpha1_data[j] = b_A[j + b_A.size(0) * j];
    }
  }
}

static double xzlarfg(int n, double *alpha1, ::coder::array<double, 2U> &x,
                      int ix0)
{
  double tau;
  tau = 0.0;
  if (n > 0) {
    double xnorm;
    xnorm = blas::xnrm2(n - 1, x, ix0);
    if (xnorm != 0.0) {
      double beta1;
      beta1 = rt_hypotd_snf(*alpha1, xnorm);
      if (*alpha1 >= 0.0) {
        beta1 = -beta1;
      }
      if (std::abs(beta1) < 1.0020841800044864E-292) {
        int i;
        int k;
        int knt;
        knt = -1;
        i = (ix0 + n) - 2;
        do {
          knt++;
          for (k = ix0; k <= i; k++) {
            x[k - 1] = 9.9792015476736E+291 * x[k - 1];
          }
          beta1 *= 9.9792015476736E+291;
          *alpha1 *= 9.9792015476736E+291;
        } while (!(std::abs(beta1) >= 1.0020841800044864E-292));
        beta1 = rt_hypotd_snf(*alpha1, blas::xnrm2(n - 1, x, ix0));
        if (*alpha1 >= 0.0) {
          beta1 = -beta1;
        }
        tau = (beta1 - *alpha1) / beta1;
        xnorm = 1.0 / (*alpha1 - beta1);
        for (k = ix0; k <= i; k++) {
          x[k - 1] = xnorm * x[k - 1];
        }
        for (k = 0; k <= knt; k++) {
          beta1 *= 1.0020841800044864E-292;
        }
        *alpha1 = beta1;
      } else {
        int i;
        tau = (beta1 - *alpha1) / beta1;
        xnorm = 1.0 / (*alpha1 - beta1);
        i = (ix0 + n) - 2;
        for (int k{ix0}; k <= i; k++) {
          x[k - 1] = xnorm * x[k - 1];
        }
        *alpha1 = beta1;
      }
    }
  }
  return tau;
}

static void xzlartg(const creal_T f, const creal_T g, double *cs, creal_T *sn)
{
  double f2;
  double fs_im;
  double fs_re;
  double gs_im;
  double gs_re;
  double scale;
  double scale_tmp;
  boolean_T guard1{false};
  scale_tmp = std::abs(f.re);
  f2 = std::abs(f.im);
  if (f2 > scale_tmp) {
    scale_tmp = f2;
  }
  f2 = std::abs(g.re);
  scale = std::abs(g.im);
  if (scale > f2) {
    f2 = scale;
  }
  scale = scale_tmp;
  if (f2 > scale_tmp) {
    scale = f2;
  }
  fs_re = f.re;
  fs_im = f.im;
  gs_re = g.re;
  gs_im = g.im;
  guard1 = false;
  if (scale >= 7.4428285367870146E+137) {
    do {
      fs_re *= 1.3435752215134178E-138;
      fs_im *= 1.3435752215134178E-138;
      gs_re *= 1.3435752215134178E-138;
      gs_im *= 1.3435752215134178E-138;
      scale *= 1.3435752215134178E-138;
    } while (!(scale < 7.4428285367870146E+137));
    guard1 = true;
  } else if (scale <= 1.3435752215134178E-138) {
    if ((g.re == 0.0) && (g.im == 0.0)) {
      *cs = 1.0;
      sn->re = 0.0;
      sn->im = 0.0;
    } else {
      do {
        fs_re *= 7.4428285367870146E+137;
        fs_im *= 7.4428285367870146E+137;
        gs_re *= 7.4428285367870146E+137;
        gs_im *= 7.4428285367870146E+137;
        scale *= 7.4428285367870146E+137;
      } while (!(scale > 1.3435752215134178E-138));
      guard1 = true;
    }
  } else {
    guard1 = true;
  }
  if (guard1) {
    double g2;
    f2 = fs_re * fs_re + fs_im * fs_im;
    g2 = gs_re * gs_re + gs_im * gs_im;
    scale = g2;
    if (1.0 > g2) {
      scale = 1.0;
    }
    if (f2 <= scale * 2.0041683600089728E-292) {
      if ((f.re == 0.0) && (f.im == 0.0)) {
        *cs = 0.0;
        g2 = rt_hypotd_snf(gs_re, gs_im);
        sn->re = gs_re / g2;
        sn->im = -gs_im / g2;
      } else {
        double g2s;
        g2s = std::sqrt(g2);
        *cs = rt_hypotd_snf(fs_re, fs_im) / g2s;
        if (scale_tmp > 1.0) {
          g2 = rt_hypotd_snf(f.re, f.im);
          fs_re = f.re / g2;
          fs_im = f.im / g2;
        } else {
          f2 = 7.4428285367870146E+137 * f.re;
          scale = 7.4428285367870146E+137 * f.im;
          g2 = rt_hypotd_snf(f2, scale);
          fs_re = f2 / g2;
          fs_im = scale / g2;
        }
        gs_re /= g2s;
        gs_im = -gs_im / g2s;
        sn->re = fs_re * gs_re - fs_im * gs_im;
        sn->im = fs_re * gs_im + fs_im * gs_re;
      }
    } else {
      scale = std::sqrt(g2 / f2 + 1.0);
      *cs = 1.0 / scale;
      g2 += f2;
      fs_re = scale * fs_re / g2;
      fs_im = scale * fs_im / g2;
      sn->re = fs_re * gs_re - fs_im * -gs_im;
      sn->im = fs_re * -gs_im + fs_im * gs_re;
    }
  }
}

static void xzlartg(const creal_T f, const creal_T g, double *cs, creal_T *sn,
                    creal_T *r)
{
  double f2s;
  double fs_im;
  double fs_re;
  double gs_im;
  double gs_re;
  double scale;
  double scale_tmp;
  int count;
  int rescaledir;
  boolean_T guard1{false};
  scale_tmp = std::abs(f.re);
  f2s = std::abs(f.im);
  if (f2s > scale_tmp) {
    scale_tmp = f2s;
  }
  f2s = std::abs(g.re);
  scale = std::abs(g.im);
  if (scale > f2s) {
    f2s = scale;
  }
  scale = scale_tmp;
  if (f2s > scale_tmp) {
    scale = f2s;
  }
  fs_re = f.re;
  fs_im = f.im;
  gs_re = g.re;
  gs_im = g.im;
  count = -1;
  rescaledir = 0;
  guard1 = false;
  if (scale >= 7.4428285367870146E+137) {
    do {
      count++;
      fs_re *= 1.3435752215134178E-138;
      fs_im *= 1.3435752215134178E-138;
      gs_re *= 1.3435752215134178E-138;
      gs_im *= 1.3435752215134178E-138;
      scale *= 1.3435752215134178E-138;
    } while (!(scale < 7.4428285367870146E+137));
    rescaledir = 1;
    guard1 = true;
  } else if (scale <= 1.3435752215134178E-138) {
    if ((g.re == 0.0) && (g.im == 0.0)) {
      *cs = 1.0;
      sn->re = 0.0;
      sn->im = 0.0;
      *r = f;
    } else {
      do {
        count++;
        fs_re *= 7.4428285367870146E+137;
        fs_im *= 7.4428285367870146E+137;
        gs_re *= 7.4428285367870146E+137;
        gs_im *= 7.4428285367870146E+137;
        scale *= 7.4428285367870146E+137;
      } while (!(scale > 1.3435752215134178E-138));
      rescaledir = -1;
      guard1 = true;
    }
  } else {
    guard1 = true;
  }
  if (guard1) {
    double f2;
    double g2;
    f2 = fs_re * fs_re + fs_im * fs_im;
    g2 = gs_re * gs_re + gs_im * gs_im;
    scale = g2;
    if (1.0 > g2) {
      scale = 1.0;
    }
    if (f2 <= scale * 2.0041683600089728E-292) {
      if ((f.re == 0.0) && (f.im == 0.0)) {
        *cs = 0.0;
        r->re = rt_hypotd_snf(g.re, g.im);
        r->im = 0.0;
        f2 = rt_hypotd_snf(gs_re, gs_im);
        sn->re = gs_re / f2;
        sn->im = -gs_im / f2;
      } else {
        g2 = std::sqrt(g2);
        *cs = rt_hypotd_snf(fs_re, fs_im) / g2;
        if (scale_tmp > 1.0) {
          f2 = rt_hypotd_snf(f.re, f.im);
          fs_re = f.re / f2;
          fs_im = f.im / f2;
        } else {
          scale = 7.4428285367870146E+137 * f.re;
          f2s = 7.4428285367870146E+137 * f.im;
          f2 = rt_hypotd_snf(scale, f2s);
          fs_re = scale / f2;
          fs_im = f2s / f2;
        }
        gs_re /= g2;
        gs_im = -gs_im / g2;
        sn->re = fs_re * gs_re - fs_im * gs_im;
        sn->im = fs_re * gs_im + fs_im * gs_re;
        r->re = *cs * f.re + (sn->re * g.re - sn->im * g.im);
        r->im = *cs * f.im + (sn->re * g.im + sn->im * g.re);
      }
    } else {
      f2s = std::sqrt(g2 / f2 + 1.0);
      r->re = f2s * fs_re;
      r->im = f2s * fs_im;
      *cs = 1.0 / f2s;
      f2 += g2;
      f2s = r->re / f2;
      scale = r->im / f2;
      sn->re = f2s * gs_re - scale * -gs_im;
      sn->im = f2s * -gs_im + scale * gs_re;
      if (rescaledir > 0) {
        for (rescaledir = 0; rescaledir <= count; rescaledir++) {
          r->re *= 7.4428285367870146E+137;
          r->im *= 7.4428285367870146E+137;
        }
      } else if (rescaledir < 0) {
        for (rescaledir = 0; rescaledir <= count; rescaledir++) {
          r->re *= 1.3435752215134178E-138;
          r->im *= 1.3435752215134178E-138;
        }
      }
    }
  }
}

} // namespace reflapack
} // namespace internal
static void lp2bp(const ::coder::array<double, 2U> &a, const double b_data[],
                  int b_size, const double c_data[], const int c_size[2],
                  double d, double wo, double bw,
                  ::coder::array<double, 2U> &at, double bt_data[],
                  int *bt_size, double ct_data[], int ct_size[2], double *dt)
{
  array<double, 2U> result;
  array<double, 2U> varargin_1;
  array<signed char, 2U> b_result;
  array<signed char, 2U> varargin_2;
  double q;
  int i;
  int i1;
  int k;
  int loop_ub_tmp;
  int m;
  short input_sizes_idx_1;
  short sizes_idx_1;
  boolean_T empty_non_axis_sizes;
  q = wo / bw;
  varargin_1.set_size(a.size(0), a.size(1));
  m = a.size(0) * a.size(1);
  for (i = 0; i < m; i++) {
    varargin_1[i] = a[i] / q;
  }
  m = c_size[1];
  varargin_2.set_size(c_size[1], c_size[1]);
  loop_ub_tmp = c_size[1] * c_size[1];
  for (i = 0; i < loop_ub_tmp; i++) {
    varargin_2[i] = 0;
  }
  if (c_size[1] > 0) {
    for (k = 0; k < m; k++) {
      varargin_2[k + varargin_2.size(0) * k] = 1;
    }
  }
  if ((varargin_1.size(0) != 0) && (varargin_1.size(1) != 0)) {
    k = varargin_1.size(0);
  } else if ((varargin_2.size(0) != 0) && (varargin_2.size(1) != 0)) {
    k = varargin_2.size(0);
  } else {
    k = varargin_1.size(0);
    if (varargin_2.size(0) > varargin_1.size(0)) {
      k = varargin_2.size(0);
    }
  }
  empty_non_axis_sizes = (k == 0);
  if (empty_non_axis_sizes ||
      ((varargin_1.size(0) != 0) && (varargin_1.size(1) != 0))) {
    input_sizes_idx_1 = static_cast<short>(varargin_1.size(1));
  } else {
    input_sizes_idx_1 = 0;
  }
  if (empty_non_axis_sizes ||
      ((varargin_2.size(0) != 0) && (varargin_2.size(1) != 0))) {
    sizes_idx_1 = static_cast<short>(varargin_2.size(1));
  } else {
    sizes_idx_1 = 0;
  }
  result.set_size(k, input_sizes_idx_1 + sizes_idx_1);
  m = input_sizes_idx_1;
  for (i = 0; i < m; i++) {
    for (i1 = 0; i1 < k; i1++) {
      result[i1 + result.size(0) * i] = varargin_1[i1 + k * i];
    }
  }
  m = sizes_idx_1;
  for (i = 0; i < m; i++) {
    for (i1 = 0; i1 < k; i1++) {
      result[i1 + result.size(0) * (i + input_sizes_idx_1)] =
          varargin_2[i1 + k * i];
    }
  }
  m = c_size[1];
  varargin_1.set_size(c_size[1], c_size[1]);
  for (i = 0; i < loop_ub_tmp; i++) {
    varargin_1[i] = 0.0;
  }
  if (c_size[1] > 0) {
    for (k = 0; k < m; k++) {
      varargin_1[k + varargin_1.size(0) * k] = 1.0;
    }
  }
  m = varargin_1.size(0) * varargin_1.size(1);
  for (i = 0; i < m; i++) {
    varargin_1[i] = -varargin_1[i];
  }
  if ((varargin_1.size(0) != 0) && (varargin_1.size(1) != 0)) {
    k = varargin_1.size(0);
  } else if (c_size[1] != 0) {
    k = c_size[1];
  } else {
    k = varargin_1.size(0);
  }
  empty_non_axis_sizes = (k == 0);
  if (empty_non_axis_sizes ||
      ((varargin_1.size(0) != 0) && (varargin_1.size(1) != 0))) {
    input_sizes_idx_1 = static_cast<short>(varargin_1.size(1));
  } else {
    input_sizes_idx_1 = 0;
  }
  if (empty_non_axis_sizes || (c_size[1] != 0)) {
    sizes_idx_1 = static_cast<short>(c_size[1]);
  } else {
    sizes_idx_1 = 0;
  }
  b_result.set_size(k, input_sizes_idx_1 + sizes_idx_1);
  m = input_sizes_idx_1;
  for (i = 0; i < m; i++) {
    for (i1 = 0; i1 < k; i1++) {
      b_result[i1 + b_result.size(0) * i] =
          static_cast<signed char>(varargin_1[i1 + k * i]);
    }
  }
  m = sizes_idx_1;
  for (i = 0; i < m; i++) {
    for (i1 = 0; i1 < k; i1++) {
      b_result[i1 + b_result.size(0) * (i + input_sizes_idx_1)] = 0;
    }
  }
  if ((result.size(0) != 0) && (result.size(1) != 0)) {
    k = result.size(1);
  } else if ((b_result.size(0) != 0) && (b_result.size(1) != 0)) {
    k = b_result.size(1);
  } else {
    k = result.size(1);
    if (b_result.size(1) > result.size(1)) {
      k = b_result.size(1);
    }
  }
  empty_non_axis_sizes = (k == 0);
  if (empty_non_axis_sizes ||
      ((result.size(0) != 0) && (result.size(1) != 0))) {
    input_sizes_idx_1 = static_cast<short>(result.size(0));
  } else {
    input_sizes_idx_1 = 0;
  }
  if (empty_non_axis_sizes ||
      ((b_result.size(0) != 0) && (b_result.size(1) != 0))) {
    sizes_idx_1 = static_cast<short>(b_result.size(0));
  } else {
    sizes_idx_1 = 0;
  }
  m = input_sizes_idx_1;
  loop_ub_tmp = sizes_idx_1;
  at.set_size(input_sizes_idx_1 + sizes_idx_1, k);
  for (i = 0; i < k; i++) {
    for (i1 = 0; i1 < m; i1++) {
      at[i1 + at.size(0) * i] = wo * result[i1 + input_sizes_idx_1 * i];
    }
  }
  for (i = 0; i < k; i++) {
    for (i1 = 0; i1 < loop_ub_tmp; i1++) {
      at[(i1 + input_sizes_idx_1) + at.size(0) * i] =
          wo * static_cast<double>(b_result[i1 + sizes_idx_1 * i]);
    }
  }
  *bt_size = b_size + static_cast<short>(c_size[1]);
  for (i = 0; i < b_size; i++) {
    bt_data[i] = wo * (b_data[i] / q);
  }
  m = static_cast<short>(c_size[1]);
  for (i = 0; i < m; i++) {
    bt_data[i + b_size] = wo * 0.0;
  }
  ct_size[0] = 1;
  ct_size[1] = c_size[1] + c_size[1];
  m = c_size[1];
  if (0 <= m - 1) {
    std::copy(&c_data[0], &c_data[m], &ct_data[0]);
  }
  m = c_size[1];
  if (0 <= m - 1) {
    std::memset(&ct_data[c_size[1]], 0,
                ((m + c_size[1]) - c_size[1]) * sizeof(double));
  }
  *dt = d;
}

static void mldivide(const ::coder::array<double, 2U> &A, const double B_data[],
                     int B_size, double Y_data[], int *Y_size)
{
  if ((A.size(0) == 0) || (A.size(1) == 0) || (B_size == 0)) {
    int loop_ub;
    *Y_size = static_cast<short>(A.size(1));
    loop_ub = static_cast<short>(A.size(1));
    if (0 <= loop_ub - 1) {
      std::memset(&Y_data[0], 0, loop_ub * sizeof(double));
    }
  } else if (A.size(0) == A.size(1)) {
    *Y_size = B_size;
    if (0 <= B_size - 1) {
      std::copy(&B_data[0], &B_data[B_size], &Y_data[0]);
    }
    internal::lusolve(A, Y_data, Y_size);
  } else {
    internal::qrsolve(A, B_data, B_size, Y_data, Y_size);
  }
}

static void mldivide(const ::coder::array<double, 2U> &A,
                     const ::coder::array<double, 2U> &B,
                     ::coder::array<double, 2U> &Y)
{
  if ((A.size(0) == 0) || (A.size(1) == 0) ||
      ((B.size(0) == 0) || (B.size(1) == 0))) {
    int loop_ub;
    Y.set_size(static_cast<int>(static_cast<short>(A.size(1))),
               static_cast<int>(static_cast<short>(B.size(1))));
    loop_ub = static_cast<short>(A.size(1)) * static_cast<short>(B.size(1));
    for (int i{0}; i < loop_ub; i++) {
      Y[i] = 0.0;
    }
  } else if (A.size(0) == A.size(1)) {
    internal::lusolve(A, B, Y);
  } else {
    internal::qrsolve(A, B, Y);
  }
}

static void zp2ss(const creal_T p_data[], int p_size, double k,
                  ::coder::array<double, 2U> &a, double b_data[], int *b_size,
                  double c_data[], int c_size[2], double *d)
{
  creal_T pf_data[501];
  creal_T vwork_data[501];
  creal_T c[3];
  creal_T x[2];
  double e_tmp_data[500];
  double a1[4];
  double b_a[4];
  double b1[2];
  double absxk;
  double scale;
  double wn;
  int b_k;
  int dim;
  int i;
  int j;
  int np;
  int vlen;
  int vstride;
  boolean_T b_tmp_data[501];
  boolean_T c_tmp_data[501];
  boolean_T d_tmp_data[501];
  boolean_T tmp_data[501];
  boolean_T oddPoles;
  for (vstride = 0; vstride < p_size; vstride++) {
    tmp_data[vstride] = std::isinf(p_data[vstride].re);
  }
  for (vstride = 0; vstride < p_size; vstride++) {
    b_tmp_data[vstride] = std::isinf(p_data[vstride].im);
  }
  for (vstride = 0; vstride < p_size; vstride++) {
    c_tmp_data[vstride] = std::isnan(p_data[vstride].re);
  }
  for (vstride = 0; vstride < p_size; vstride++) {
    d_tmp_data[vstride] = std::isnan(p_data[vstride].im);
  }
  for (vstride = 0; vstride < p_size; vstride++) {
    tmp_data[vstride] = ((!tmp_data[vstride]) && (!b_tmp_data[vstride]) &&
                         ((!c_tmp_data[vstride]) && (!d_tmp_data[vstride])));
  }
  dim = p_size - 1;
  np = 0;
  vlen = 0;
  for (i = 0; i <= dim; i++) {
    if (tmp_data[i]) {
      np++;
      pf_data[vlen] = p_data[i];
      vlen++;
    }
  }
  dim = 2;
  if (np != 1) {
    dim = 1;
  }
  oddPoles = true;
  if (np != 0) {
    if (np == 1) {
      oddPoles = internal::cplxpairv(pf_data, &np, 0.0);
    } else {
      if (dim <= 1) {
        vlen = np;
      } else {
        vlen = 1;
      }
      if (vlen != 1) {
        oddPoles = internal::cplxpairv(pf_data, &np, 0.0);
      } else {
        if (dim <= 1) {
          i = np;
        } else {
          i = 1;
        }
        vlen = i - 1;
        vstride = 1;
        for (b_k = 0; b_k <= dim - 2; b_k++) {
          vstride *= np;
        }
        for (j = 0; j < vstride; j++) {
          boolean_T paired;
          for (b_k = 0; b_k <= vlen; b_k++) {
            vwork_data[b_k] = pf_data[j + b_k * vstride];
          }
          paired = internal::cplxpairv(vwork_data, &i, 0.0);
          for (b_k = 0; b_k <= vlen; b_k++) {
            pf_data[j + b_k * vstride] = vwork_data[b_k];
          }
          if ((!oddPoles) || (!paired)) {
            oddPoles = false;
          }
        }
      }
    }
  }
  if (!oddPoles) {
    if (np == 0) {
      wn = 0.0;
    } else {
      wn = 0.0;
      if (np == 1) {
        wn = rt_hypotd_snf(pf_data[0].re, pf_data[0].im);
      } else {
        scale = 3.3121686421112381E-170;
        for (b_k = 0; b_k < np; b_k++) {
          double t;
          absxk = std::abs(pf_data[b_k].re);
          if (absxk > scale) {
            t = scale / absxk;
            wn = wn * t * t + 1.0;
            scale = absxk;
          } else {
            t = absxk / scale;
            wn += t * t;
          }
          absxk = std::abs(pf_data[b_k].im);
          if (absxk > scale) {
            t = scale / absxk;
            wn = wn * t * t + 1.0;
            scale = absxk;
          } else {
            t = absxk / scale;
            wn += t * t;
          }
        }
        wn = scale * std::sqrt(wn);
      }
    }
    wn = 1.0E+6 * static_cast<double>(np) * wn * 2.2204460492503131E-16 +
         2.2204460492503131E-16;
    dim = 2;
    if (np != 1) {
      dim = 1;
    }
    if (np != 0) {
      if (np == 1) {
        internal::cplxpairv(pf_data, &np, wn);
      } else {
        if (dim <= 1) {
          vlen = np;
        } else {
          vlen = 1;
        }
        if (vlen != 1) {
          internal::cplxpairv(pf_data, &np, wn);
        } else {
          if (dim <= 1) {
            i = np;
          } else {
            i = 1;
          }
          vlen = i - 1;
          vstride = 1;
          for (b_k = 0; b_k <= dim - 2; b_k++) {
            vstride *= np;
          }
          for (j = 0; j < vstride; j++) {
            for (b_k = 0; b_k <= vlen; b_k++) {
              vwork_data[b_k] = pf_data[j + b_k * vstride];
            }
            internal::cplxpairv(vwork_data, &i, wn);
            for (b_k = 0; b_k <= vlen; b_k++) {
              pf_data[j + b_k * vstride] = vwork_data[b_k];
            }
          }
        }
      }
    }
  }
  a.set_size(np, np);
  dim = np * np;
  for (vstride = 0; vstride < dim; vstride++) {
    a[vstride] = 0.0;
  }
  *b_size = np;
  c_size[0] = 1;
  c_size[1] = np;
  if (0 <= np - 1) {
    std::memset(&b_data[0], 0, np * sizeof(double));
    std::memset(&c_data[0], 0, np * sizeof(double));
  }
  *d = 1.0;
  oddPoles = false;
  if (rt_remd_snf(static_cast<double>(np), 2.0) != 0.0) {
    a[0] = pf_data[np - 1].re;
    b_data[0] = 1.0;
    c_data[0] = 1.0;
    *d = 0.0;
    np--;
    oddPoles = true;
  }
  for (i = 1; i < np; i += 2) {
    b1[0] = i;
    b1[1] = static_cast<double>(i) + 1.0;
    c[0].re = 1.0;
    c[0].im = 0.0;
    for (j = 0; j < 2; j++) {
      dim = static_cast<int>(b1[j]) - 1;
      x[j] = pf_data[dim];
      wn = -pf_data[dim].re;
      scale = -pf_data[dim].im;
      absxk = wn * c[j].im + scale * c[j].re;
      c[j + 1].re = wn * c[j].re - scale * c[j].im;
      c[j + 1].im = absxk;
      for (b_k = j + 1; b_k >= 2; b_k--) {
        wn = x[j].re;
        scale = x[j].im;
        c[1].re -= wn * c[0].re - scale * c[0].im;
        c[1].im -= wn * c[0].im + scale * c[0].re;
      }
    }
    x[0] = pf_data[i - 1];
    x[1] = pf_data[i];
    wn = std::sqrt(rt_hypotd_snf(x[0].re, x[0].im) *
                   rt_hypotd_snf(x[1].re, x[1].im));
    if (wn == 0.0) {
      wn = 1.0;
    }
    absxk = 1.0 / wn;
    wn = (1.0 - -c[1].re * 0.0) / absxk;
    b_a[1] = wn;
    b_a[0] = -c[1].re - wn * 0.0;
    wn = (0.0 - -c[2].re * 0.0) / absxk;
    b_a[3] = wn;
    b_a[2] = -c[2].re - wn * 0.0;
    for (vstride = 0; vstride < 2; vstride++) {
      wn = b_a[vstride + 2];
      scale = b_a[vstride];
      a1[vstride] = scale + wn * 0.0;
      a1[vstride + 2] = scale * 0.0 + wn * absxk;
    }
    b1[1] = 0.0 / absxk;
    b1[0] = 1.0 - b1[1] * 0.0;
    if (oddPoles) {
      j = i - 1;
    } else {
      j = i - 2;
    }
    if (j == -1) {
      a[0] = a1[0];
      a[1] = a1[1];
      c_data[0] = 0.0;
      a[a.size(0)] = a1[2];
      a[a.size(0) + 1] = a1[3];
      c_data[1] = absxk;
    } else {
      for (vstride = 0; vstride <= j; vstride++) {
        a[(static_cast<short>(static_cast<short>(j) + 2) +
           a.size(0) * vstride) -
          1] = b1[0] * c_data[vstride];
        a[(static_cast<short>(static_cast<short>(static_cast<short>(j) + 1) +
                              2) +
           a.size(0) * vstride) -
          1] = b1[1] * c_data[vstride];
      }
      a[(static_cast<short>(static_cast<short>(j) + 2) +
         a.size(0) * (static_cast<short>(static_cast<short>(j) + 2) - 1)) -
        1] = a1[0];
      a[(static_cast<short>(static_cast<short>(static_cast<short>(j) + 1) + 2) +
         a.size(0) * (static_cast<short>(static_cast<short>(j) + 2) - 1)) -
        1] = a1[1];
      a[(static_cast<short>(static_cast<short>(j) + 2) +
         a.size(0) * (static_cast<short>(
                          static_cast<short>(static_cast<short>(j) + 1) + 2) -
                      1)) -
        1] = a1[2];
      a[(static_cast<short>(static_cast<short>(static_cast<short>(j) + 1) + 2) +
         a.size(0) * (static_cast<short>(
                          static_cast<short>(static_cast<short>(j) + 1) + 2) -
                      1)) -
        1] = a1[3];
      vlen = j + 1;
      for (vstride = 0; vstride <= j; vstride++) {
        e_tmp_data[vstride] = 0.0 * c_data[vstride];
      }
      if (0 <= vlen - 1) {
        std::copy(&e_tmp_data[0], &e_tmp_data[vlen], &c_data[0]);
      }
      c_data[static_cast<short>(static_cast<short>(j) + 2) - 1] = 0.0;
      c_data[static_cast<short>(static_cast<short>(static_cast<short>(j) + 1) +
                                2) -
             1] = absxk;
    }
    b_data[j + 1] = b1[0] * *d;
    b_data[j + 2] = b1[1] * *d;
    *d = 0.0;
  }
  c_size[0] = 1;
  dim = c_size[1] - 1;
  for (vstride = 0; vstride <= dim; vstride++) {
    c_data[vstride] *= k;
  }
  *d *= k;
}

} // namespace coder
static void eml_rand_mt19937ar_stateful_init(butterBandPassStackData *SD)
{
  static const unsigned int uv[625]{
      5489U,       1301868182U, 2938499221U, 2950281878U, 1875628136U,
      751856242U,  944701696U,  2243192071U, 694061057U,  219885934U,
      2066767472U, 3182869408U, 485472502U,  2336857883U, 1071588843U,
      3418470598U, 951210697U,  3693558366U, 2923482051U, 1793174584U,
      2982310801U, 1586906132U, 1951078751U, 1808158765U, 1733897588U,
      431328322U,  4202539044U, 530658942U,  1714810322U, 3025256284U,
      3342585396U, 1937033938U, 2640572511U, 1654299090U, 3692403553U,
      4233871309U, 3497650794U, 862629010U,  2943236032U, 2426458545U,
      1603307207U, 1133453895U, 3099196360U, 2208657629U, 2747653927U,
      931059398U,  761573964U,  3157853227U, 785880413U,  730313442U,
      124945756U,  2937117055U, 3295982469U, 1724353043U, 3021675344U,
      3884886417U, 4010150098U, 4056961966U, 699635835U,  2681338818U,
      1339167484U, 720757518U,  2800161476U, 2376097373U, 1532957371U,
      3902664099U, 1238982754U, 3725394514U, 3449176889U, 3570962471U,
      4287636090U, 4087307012U, 3603343627U, 202242161U,  2995682783U,
      1620962684U, 3704723357U, 371613603U,  2814834333U, 2111005706U,
      624778151U,  2094172212U, 4284947003U, 1211977835U, 991917094U,
      1570449747U, 2962370480U, 1259410321U, 170182696U,  146300961U,
      2836829791U, 619452428U,  2723670296U, 1881399711U, 1161269684U,
      1675188680U, 4132175277U, 780088327U,  3409462821U, 1036518241U,
      1834958505U, 3048448173U, 161811569U,  618488316U,  44795092U,
      3918322701U, 1924681712U, 3239478144U, 383254043U,  4042306580U,
      2146983041U, 3992780527U, 3518029708U, 3545545436U, 3901231469U,
      1896136409U, 2028528556U, 2339662006U, 501326714U,  2060962201U,
      2502746480U, 561575027U,  581893337U,  3393774360U, 1778912547U,
      3626131687U, 2175155826U, 319853231U,  986875531U,  819755096U,
      2915734330U, 2688355739U, 3482074849U, 2736559U,    2296975761U,
      1029741190U, 2876812646U, 690154749U,  579200347U,  4027461746U,
      1285330465U, 2701024045U, 4117700889U, 759495121U,  3332270341U,
      2313004527U, 2277067795U, 4131855432U, 2722057515U, 1264804546U,
      3848622725U, 2211267957U, 4100593547U, 959123777U,  2130745407U,
      3194437393U, 486673947U,  1377371204U, 17472727U,   352317554U,
      3955548058U, 159652094U,  1232063192U, 3835177280U, 49423123U,
      3083993636U, 733092U,     2120519771U, 2573409834U, 1112952433U,
      3239502554U, 761045320U,  1087580692U, 2540165110U, 641058802U,
      1792435497U, 2261799288U, 1579184083U, 627146892U,  2165744623U,
      2200142389U, 2167590760U, 2381418376U, 1793358889U, 3081659520U,
      1663384067U, 2009658756U, 2689600308U, 739136266U,  2304581039U,
      3529067263U, 591360555U,  525209271U,  3131882996U, 294230224U,
      2076220115U, 3113580446U, 1245621585U, 1386885462U, 3203270426U,
      123512128U,  12350217U,   354956375U,  4282398238U, 3356876605U,
      3888857667U, 157639694U,  2616064085U, 1563068963U, 2762125883U,
      4045394511U, 4180452559U, 3294769488U, 1684529556U, 1002945951U,
      3181438866U, 22506664U,   691783457U,  2685221343U, 171579916U,
      3878728600U, 2475806724U, 2030324028U, 3331164912U, 1708711359U,
      1970023127U, 2859691344U, 2588476477U, 2748146879U, 136111222U,
      2967685492U, 909517429U,  2835297809U, 3206906216U, 3186870716U,
      341264097U,  2542035121U, 3353277068U, 548223577U,  3170936588U,
      1678403446U, 297435620U,  2337555430U, 466603495U,  1132321815U,
      1208589219U, 696392160U,  894244439U,  2562678859U, 470224582U,
      3306867480U, 201364898U,  2075966438U, 1767227936U, 2929737987U,
      3674877796U, 2654196643U, 3692734598U, 3528895099U, 2796780123U,
      3048728353U, 842329300U,  191554730U,  2922459673U, 3489020079U,
      3979110629U, 1022523848U, 2202932467U, 3583655201U, 3565113719U,
      587085778U,  4176046313U, 3013713762U, 950944241U,  396426791U,
      3784844662U, 3477431613U, 3594592395U, 2782043838U, 3392093507U,
      3106564952U, 2829419931U, 1358665591U, 2206918825U, 3170783123U,
      31522386U,   2988194168U, 1782249537U, 1105080928U, 843500134U,
      1225290080U, 1521001832U, 3605886097U, 2802786495U, 2728923319U,
      3996284304U, 903417639U,  1171249804U, 1020374987U, 2824535874U,
      423621996U,  1988534473U, 2493544470U, 1008604435U, 1756003503U,
      1488867287U, 1386808992U, 732088248U,  1780630732U, 2482101014U,
      976561178U,  1543448953U, 2602866064U, 2021139923U, 1952599828U,
      2360242564U, 2117959962U, 2753061860U, 2388623612U, 4138193781U,
      2962920654U, 2284970429U, 766920861U,  3457264692U, 2879611383U,
      815055854U,  2332929068U, 1254853997U, 3740375268U, 3799380844U,
      4091048725U, 2006331129U, 1982546212U, 686850534U,  1907447564U,
      2682801776U, 2780821066U, 998290361U,  1342433871U, 4195430425U,
      607905174U,  3902331779U, 2454067926U, 1708133115U, 1170874362U,
      2008609376U, 3260320415U, 2211196135U, 433538229U,  2728786374U,
      2189520818U, 262554063U,  1182318347U, 3710237267U, 1221022450U,
      715966018U,  2417068910U, 2591870721U, 2870691989U, 3418190842U,
      4238214053U, 1540704231U, 1575580968U, 2095917976U, 4078310857U,
      2313532447U, 2110690783U, 4056346629U, 4061784526U, 1123218514U,
      551538993U,  597148360U,  4120175196U, 3581618160U, 3181170517U,
      422862282U,  3227524138U, 1713114790U, 662317149U,  1230418732U,
      928171837U,  1324564878U, 1928816105U, 1786535431U, 2878099422U,
      3290185549U, 539474248U,  1657512683U, 552370646U,  1671741683U,
      3655312128U, 1552739510U, 2605208763U, 1441755014U, 181878989U,
      3124053868U, 1447103986U, 3183906156U, 1728556020U, 3502241336U,
      3055466967U, 1013272474U, 818402132U,  1715099063U, 2900113506U,
      397254517U,  4194863039U, 1009068739U, 232864647U,  2540223708U,
      2608288560U, 2415367765U, 478404847U,  3455100648U, 3182600021U,
      2115988978U, 434269567U,  4117179324U, 3461774077U, 887256537U,
      3545801025U, 286388911U,  3451742129U, 1981164769U, 786667016U,
      3310123729U, 3097811076U, 2224235657U, 2959658883U, 3370969234U,
      2514770915U, 3345656436U, 2677010851U, 2206236470U, 271648054U,
      2342188545U, 4292848611U, 3646533909U, 3754009956U, 3803931226U,
      4160647125U, 1477814055U, 4043852216U, 1876372354U, 3133294443U,
      3871104810U, 3177020907U, 2074304428U, 3479393793U, 759562891U,
      164128153U,  1839069216U, 2114162633U, 3989947309U, 3611054956U,
      1333547922U, 835429831U,  494987340U,  171987910U,  1252001001U,
      370809172U,  3508925425U, 2535703112U, 1276855041U, 1922855120U,
      835673414U,  3030664304U, 613287117U,  171219893U,  3423096126U,
      3376881639U, 2287770315U, 1658692645U, 1262815245U, 3957234326U,
      1168096164U, 2968737525U, 2655813712U, 2132313144U, 3976047964U,
      326516571U,  353088456U,  3679188938U, 3205649712U, 2654036126U,
      1249024881U, 880166166U,  691800469U,  2229503665U, 1673458056U,
      4032208375U, 1851778863U, 2563757330U, 376742205U,  1794655231U,
      340247333U,  1505873033U, 396524441U,  879666767U,  3335579166U,
      3260764261U, 3335999539U, 506221798U,  4214658741U, 975887814U,
      2080536343U, 3360539560U, 571586418U,  138896374U,  4234352651U,
      2737620262U, 3928362291U, 1516365296U, 38056726U,   3599462320U,
      3585007266U, 3850961033U, 471667319U,  1536883193U, 2310166751U,
      1861637689U, 2530999841U, 4139843801U, 2710569485U, 827578615U,
      2012334720U, 2907369459U, 3029312804U, 2820112398U, 1965028045U,
      35518606U,   2478379033U, 643747771U,  1924139484U, 4123405127U,
      3811735531U, 3429660832U, 3285177704U, 1948416081U, 1311525291U,
      1183517742U, 1739192232U, 3979815115U, 2567840007U, 4116821529U,
      213304419U,  4125718577U, 1473064925U, 2442436592U, 1893310111U,
      4195361916U, 3747569474U, 828465101U,  2991227658U, 750582866U,
      1205170309U, 1409813056U, 678418130U,  1171531016U, 3821236156U,
      354504587U,  4202874632U, 3882511497U, 1893248677U, 1903078632U,
      26340130U,   2069166240U, 3657122492U, 3725758099U, 831344905U,
      811453383U,  3447711422U, 2434543565U, 4166886888U, 3358210805U,
      4142984013U, 2988152326U, 3527824853U, 982082992U,  2809155763U,
      190157081U,  3340214818U, 2365432395U, 2548636180U, 2894533366U,
      3474657421U, 2372634704U, 2845748389U, 43024175U,   2774226648U,
      1987702864U, 3186502468U, 453610222U,  4204736567U, 1392892630U,
      2471323686U, 2470534280U, 3541393095U, 4269885866U, 3909911300U,
      759132955U,  1482612480U, 667715263U,  1795580598U, 2337923983U,
      3390586366U, 581426223U,  1515718634U, 476374295U,  705213300U,
      363062054U,  2084697697U, 2407503428U, 2292957699U, 2426213835U,
      2199989172U, 1987356470U, 4026755612U, 2147252133U, 270400031U,
      1367820199U, 2369854699U, 2844269403U, 79981964U,   624U};
  std::copy(&uv[0], &uv[625], &SD->pd->state[0]);
}

static derivedAudioPlugin *getPluginInstance(butterBandPassStackData *SD)
{
  if (!SD->pd->plugin_not_empty) {
    //  Pass constructor args to plugin.
    SD->pd->plugin.f0 = 1000.0;
    SD->pd->plugin.q = 0.25;
    SD->pd->plugin.noise_gain = 0.1;
    SD->pd->plugin.output = 1.0;
    SD->pd->plugin.noise_switch = true;
    SD->pd->plugin.inicial.set_size(8, 2);
    for (int i{0}; i < 16; i++) {
      SD->pd->plugin.inicial[i] = 0.0;
    }
    SD->pd->plugin.b.set_size(1, 2);
    SD->pd->plugin.b[0] = 0.0;
    SD->pd->plugin.b[1] = 0.0;
    SD->pd->plugin.a.set_size(1, 2);
    SD->pd->plugin.a[0] = 0.0;
    SD->pd->plugin.a[1] = 0.0;
    SD->pd->plugin.orden = 2.0;
    SD->pd->plugin.PrivateSampleRate = 44100.0;
    SD->pd->plugin.PrivateLatency = 0;
    if (!SD->pd->thisPtr_not_empty) {
      SD->pd->thisPtr = 0ULL;
      SD->pd->thisPtr_not_empty = true;
    }
    SD->pd->plugin_not_empty = true;
  }
  return &SD->pd->plugin;
}

static void getPluginInstance_init(butterBandPassStackData *SD)
{
  SD->pd->plugin_not_empty = false;
}

static double rt_atan2d_snf(double u0, double u1)
{
  double y;
  if (std::isnan(u0) || std::isnan(u1)) {
    y = rtNaN;
  } else if (std::isinf(u0) && std::isinf(u1)) {
    int b_u0;
    int b_u1;
    if (u0 > 0.0) {
      b_u0 = 1;
    } else {
      b_u0 = -1;
    }
    if (u1 > 0.0) {
      b_u1 = 1;
    } else {
      b_u1 = -1;
    }
    y = std::atan2(static_cast<double>(b_u0), static_cast<double>(b_u1));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = std::atan2(u0, u1);
  }
  return y;
}

static double rt_hypotd_snf(double u0, double u1)
{
  double a;
  double y;
  a = std::abs(u0);
  y = std::abs(u1);
  if (a < y) {
    a /= y;
    y *= std::sqrt(a * a + 1.0);
  } else if (a > y) {
    y /= a;
    y = a * std::sqrt(y * y + 1.0);
  } else if (!std::isnan(y)) {
    y = a * 1.4142135623730951;
  }
  return y;
}

static double rt_remd_snf(double u0, double u1)
{
  double y;
  if (std::isnan(u0) || std::isnan(u1) || std::isinf(u0)) {
    y = rtNaN;
  } else if (std::isinf(u1)) {
    y = u0;
  } else if ((u1 != 0.0) && (u1 != std::trunc(u1))) {
    double q;
    q = std::abs(u0 / u1);
    if (!(std::abs(q - std::floor(q + 0.5)) > DBL_EPSILON * q)) {
      y = 0.0 * u0;
    } else {
      y = std::fmod(u0, u1);
    }
  } else {
    y = std::fmod(u0, u1);
  }
  return y;
}

derivedAudioPlugin::~derivedAudioPlugin()
{
}

derivedAudioPlugin::derivedAudioPlugin()
{
}

void butterBandPass_initialize(butterBandPassStackData *SD)
{
  SD->pd->thisPtr_not_empty = false;
  getPluginInstance_init(SD);
  eml_rand_mt19937ar_stateful_init(SD);
}

void butterBandPass_terminate()
{
  // (no terminate code required)
}

void createPluginInstance(butterBandPassStackData *SD,
                          unsigned long long thisPtr)
{
  if (!SD->pd->thisPtr_not_empty) {
    SD->pd->thisPtr = thisPtr;
    SD->pd->thisPtr_not_empty = true;
  }
  getPluginInstance(SD);
}

int getLatencyInSamplesCImpl(butterBandPassStackData *SD)
{
  derivedAudioPlugin *plugin;
  plugin = getPluginInstance(SD);
  return plugin->PrivateLatency;
}

void onParamChangeCImpl(butterBandPassStackData *SD, int paramIdx, double value)
{
  derivedAudioPlugin *plugin;
  double tmp_data[2003];
  double b_tmp_data[1003];
  double b_fc1[2];
  int b_tmp_size[2];
  int tmp_size[2];
  plugin = getPluginInstance(SD);
  switch (paramIdx) {
  case 0: {
    double fN;
    double fc1;
    double fs;
    double orden;
    double q;
    int i;
    int loop_ub;
    plugin->f0 = value;
    //  actualizar el valor de la propiedad
    fs = plugin->PrivateSampleRate;
    fc1 = plugin->f0;
    q = plugin->q;
    orden = plugin->orden;
    //  Butterworth filter coefficients
    fN = fs / 2.0;
    fs = fc1 / q;
    q = fc1 * fc1;
    fc1 = (std::sqrt(fs * fs + 4.0 * q) - fs) / 2.0;
    fs = q / fc1;
    if (fc1 <= 20.0) {
      fc1 = 20.0;
    } else if (fs >= 20000.0) {
      fs = 20000.0;
    }
    //  debug
    b_fc1[0] = fc1 / fN;
    b_fc1[1] = fs / fN;
    coder::butter(orden, b_fc1, tmp_data, tmp_size, b_tmp_data, b_tmp_size);
    plugin->b.set_size(1, tmp_size[1]);
    loop_ub = tmp_size[1];
    for (i = 0; i < loop_ub; i++) {
      plugin->b[i] = tmp_data[i];
    }
    plugin->a.set_size(1, b_tmp_size[1]);
    loop_ub = b_tmp_size[1];
    for (i = 0; i < loop_ub; i++) {
      plugin->a[i] = b_tmp_data[i];
    }
  } break;
  case 1: {
    double fN;
    double fc1;
    double fs;
    double orden;
    double q;
    int i;
    int loop_ub;
    plugin->q = value;
    fs = plugin->PrivateSampleRate;
    fc1 = plugin->f0;
    q = plugin->q;
    orden = plugin->orden;
    //  Butterworth filter coefficients
    fN = fs / 2.0;
    fs = fc1 / q;
    q = fc1 * fc1;
    fc1 = (std::sqrt(fs * fs + 4.0 * q) - fs) / 2.0;
    fs = q / fc1;
    if (fc1 <= 20.0) {
      fc1 = 20.0;
    } else if (fs >= 20000.0) {
      fs = 20000.0;
    }
    //  debug
    b_fc1[0] = fc1 / fN;
    b_fc1[1] = fs / fN;
    coder::butter(orden, b_fc1, tmp_data, tmp_size, b_tmp_data, b_tmp_size);
    plugin->b.set_size(1, tmp_size[1]);
    loop_ub = tmp_size[1];
    for (i = 0; i < loop_ub; i++) {
      plugin->b[i] = tmp_data[i];
    }
    plugin->a.set_size(1, b_tmp_size[1]);
    loop_ub = b_tmp_size[1];
    for (i = 0; i < loop_ub; i++) {
      plugin->a[i] = b_tmp_data[i];
    }
  } break;
  case 2:
    plugin->noise_gain = value;
    break;
  case 3:
    plugin->noise_switch = (value != 0.0);
    break;
  case 4:
    plugin->output = value;
    break;
  }
}

void processEntryPoint(butterBandPassStackData *SD, double samplesPerFrame,
                       const double i1_data[], const int i1_size[1],
                       const double i2_data[], const int i2_size[1],
                       double o1_data[], int o1_size[1], double o2_data[],
                       int o2_size[1])
{
  static const double dv[4]{0.049922035, -0.095993537, 0.050612699,
                            -0.004408786};
  static const double dv1[4]{1.0, -2.494956002, 2.017265875, -0.5221894};
  derivedAudioPlugin *plugin;
  coder::array<double, 2U> a;
  coder::array<double, 2U> b;
  coder::array<double, 2U> pink;
  coder::array<double, 2U> r;
  coder::array<double, 2U> t1;
  coder::array<double, 2U> white;
  coder::array<double, 2U> zi;
  double b_pink[2];
  double a1;
  int c;
  int i;
  int i1;
  int j;
  int jend;
  int k;
  int na;
  int naxpy;
  int nb;
  int ndbuffer;
  int niccp;
  int nx;
  int offset;
  plugin = getPluginInstance(SD);
  pink.set_size(i1_size[0], 2);
  niccp = i1_size[0];
  for (i = 0; i < niccp; i++) {
    pink[i] = i1_data[i];
  }
  niccp = i2_size[0];
  for (i = 0; i < niccp; i++) {
    pink[i + pink.size(0)] = i2_data[i];
  }
  b.set_size(1, plugin->b.size(1));
  niccp = plugin->b.size(1);
  for (i = 0; i < niccp; i++) {
    b[i] = plugin->b[i];
  }
  a.set_size(1, plugin->a.size(1));
  niccp = plugin->a.size(1);
  for (i = 0; i < niccp; i++) {
    a[i] = plugin->a[i];
  }
  zi.set_size(plugin->inicial.size(0), 2);
  niccp = plugin->inicial.size(0) * 2;
  for (i = 0; i < niccp; i++) {
    zi[i] = plugin->inicial[i];
  }
  na = a.size(1);
  nb = b.size(1);
  if (a.size(1) > b.size(1)) {
    ndbuffer = a.size(1) - 1;
  } else {
    ndbuffer = b.size(1) - 1;
  }
  a1 = a[0];
  if ((!std::isinf(a[0])) && (!std::isnan(a[0])) && (!(a[0] == 0.0)) &&
      (a[0] != 1.0)) {
    for (k = 0; k < nb; k++) {
      b[k] = b[k] / a1;
    }
    for (k = 2; k <= na; k++) {
      a[k - 1] = a[k - 1] / a1;
    }
    a[0] = 1.0;
  }
  t1.set_size(static_cast<int>(static_cast<short>(pink.size(0))), 2);
  nx = pink.size(0);
  r.set_size(ndbuffer, 2);
  niccp = ndbuffer << 1;
  for (i = 0; i < niccp; i++) {
    r[i] = 0.0;
  }
  niccp = pink.size(0);
  if (niccp >= ndbuffer) {
    niccp = ndbuffer;
  }
  i = niccp + 1;
  for (c = 0; c < 2; c++) {
    offset = c * nx;
    for (k = 0; k < niccp; k++) {
      t1[offset + k] = zi[k + zi.size(0) * c];
    }
    for (k = i; k <= nx; k++) {
      t1[(offset + k) - 1] = 0.0;
    }
  }
  i = pink.size(0) - 1;
  i1 = pink.size(0) - 1;
  for (c = 0; c < 2; c++) {
    int i2;
    int offsetzf;
    offset = c * nx;
    if ((na == 1) && (nx >= (nb << 1))) {
      for (k = 0; k < nb; k++) {
        niccp = (offset + k) + 1;
        jend = offset + nx;
        for (j = niccp; j <= jend; j++) {
          t1[j - 1] = t1[j - 1] + b[k] * pink[(j - k) - 1];
        }
      }
    } else {
      for (k = 0; k < nx; k++) {
        niccp = offset + k;
        jend = nx - k;
        if (jend < nb) {
          naxpy = jend;
        } else {
          naxpy = nb;
        }
        for (j = 0; j < naxpy; j++) {
          i2 = niccp + j;
          t1[i2] = t1[i2] + pink[niccp] * b[j];
        }
        if (jend - 1 < na - 1) {
          naxpy = jend - 2;
        } else {
          naxpy = na - 2;
        }
        a1 = -t1[niccp];
        for (j = 0; j <= naxpy; j++) {
          i2 = (niccp + j) + 1;
          t1[i2] = t1[i2] + a1 * a[j + 1];
        }
      }
    }
    offsetzf = c * ndbuffer - 1;
    if (nx < ndbuffer) {
      niccp = ndbuffer - nx;
      for (k = 0; k < niccp; k++) {
        r[(offsetzf + k) + 1] = zi[(k + nx) + zi.size(0) * c];
      }
    }
    if (nx >= nb) {
      jend = (nx - nb) + 1;
    } else {
      jend = 0;
    }
    for (k = jend; k <= i; k++) {
      niccp = nx - k;
      naxpy = (nb - nx) + k;
      a1 = pink[offset + k];
      for (j = 0; j < naxpy; j++) {
        i2 = (offsetzf + j) + 1;
        r[i2] = r[i2] + a1 * b[niccp + j];
      }
    }
    if (nx >= na) {
      jend = (nx - na) + 1;
    } else {
      jend = 0;
    }
    for (k = jend; k <= i1; k++) {
      niccp = nx - k;
      naxpy = (na - nx) + k;
      a1 = -t1[offset + k];
      for (j = 0; j < naxpy; j++) {
        i2 = (offsetzf + j) + 1;
        r[i2] = r[i2] + a1 * a[niccp + j];
      }
    }
  }
  plugin->inicial.set_size(r.size(0), 2);
  niccp = r.size(0) * 2;
  for (i = 0; i < niccp; i++) {
    plugin->inicial[i] = r[i];
  }
  if (plugin->noise_switch) {
    double b_b;
    b_pink[0] = pink.size(0);
    b_pink[1] = 2.0;
    coder::b_rand(SD, b_pink, white);
    niccp = white.size(0) * 2;
    white.set_size(white.size(0), 2);
    for (i = 0; i < niccp; i++) {
      white[i] = white[i] - 0.5;
    }
    //  señal de ruido blanco
    nx = white.size(0);
    pink.set_size(static_cast<int>(static_cast<short>(white.size(0))), 2);
    niccp = static_cast<short>(white.size(0)) * 2;
    for (i = 0; i < niccp; i++) {
      pink[i] = 0.0;
    }
    for (c = 0; c < 2; c++) {
      offset = c * nx;
      for (k = 0; k < nx; k++) {
        niccp = offset + k;
        jend = nx - k;
        if (jend < 4) {
          naxpy = jend;
        } else {
          naxpy = 4;
        }
        for (j = 0; j < naxpy; j++) {
          i = niccp + j;
          pink[i] = pink[i] + white[niccp] * dv[j];
        }
        if (jend - 1 < 3) {
          naxpy = jend - 2;
        } else {
          naxpy = 2;
        }
        a1 = -pink[niccp];
        for (j = 0; j <= naxpy; j++) {
          i = (niccp + j) + 1;
          pink[i] = pink[i] + a1 * dv1[j + 1];
        }
      }
    }
    a1 = plugin->noise_gain;
    b_b = plugin->output;
    niccp = t1.size(0) * 2;
    t1.set_size(t1.size(0), 2);
    for (i = 0; i < niccp; i++) {
      t1[i] = (t1[i] + pink[i] * a1) * b_b;
    }
    //  señal filtrada mas ruido
  } else {
    a1 = plugin->output;
    niccp = t1.size(0) * 2;
    t1.set_size(t1.size(0), 2);
    for (i = 0; i < niccp; i++) {
      t1[i] = t1[i] * a1;
    }
  }
  if (1.0 > samplesPerFrame) {
    niccp = 0;
  } else {
    niccp = static_cast<int>(samplesPerFrame);
  }
  o1_size[0] = niccp;
  for (i = 0; i < niccp; i++) {
    o1_data[i] = t1[i];
  }
  if (1.0 > samplesPerFrame) {
    niccp = 0;
  } else {
    niccp = static_cast<int>(samplesPerFrame);
  }
  o2_size[0] = niccp;
  for (i = 0; i < niccp; i++) {
    o2_data[i] = t1[i + t1.size(0)];
  }
}

void resetCImpl(butterBandPassStackData *SD, double rate)
{
  derivedAudioPlugin *plugin;
  double tmp_data[2003];
  double b_tmp_data[1003];
  double b_fc1[2];
  double fN;
  double fc1;
  double fs;
  double orden;
  int b_tmp_size[2];
  int tmp_size[2];
  int i;
  int plugin_idx_0;
  plugin = getPluginInstance(SD);
  plugin->PrivateSampleRate = rate;
  plugin_idx_0 = static_cast<int>(plugin->orden * 2.0);
  plugin->inicial.set_size(plugin_idx_0, 2);
  plugin_idx_0 <<= 1;
  for (i = 0; i < plugin_idx_0; i++) {
    plugin->inicial[i] = 0.0;
  }
  double q;
  fs = plugin->PrivateSampleRate;
  fc1 = plugin->f0;
  q = plugin->q;
  orden = plugin->orden;
  //  Butterworth filter coefficients
  fN = fs / 2.0;
  fs = fc1 / q;
  q = fc1 * fc1;
  fc1 = (std::sqrt(fs * fs + 4.0 * q) - fs) / 2.0;
  fs = q / fc1;
  if (fc1 <= 20.0) {
    fc1 = 20.0;
  } else if (fs >= 20000.0) {
    fs = 20000.0;
  }
  //  debug
  b_fc1[0] = fc1 / fN;
  b_fc1[1] = fs / fN;
  coder::butter(orden, b_fc1, tmp_data, tmp_size, b_tmp_data, b_tmp_size);
  plugin->b.set_size(1, tmp_size[1]);
  plugin_idx_0 = tmp_size[1];
  for (i = 0; i < plugin_idx_0; i++) {
    plugin->b[i] = tmp_data[i];
  }
  plugin->a.set_size(1, b_tmp_size[1]);
  plugin_idx_0 = b_tmp_size[1];
  for (i = 0; i < plugin_idx_0; i++) {
    plugin->a[i] = b_tmp_data[i];
  }
}

// End of code generation (butterBandPass.cpp)
