//
// butterBandPass.h
//
// Code generation for function 'butterBandPass'
//

#ifndef BUTTERBANDPASS_H
#define BUTTERBANDPASS_H

// Include files
#include "rtwtypes.h"
#include "coder_array.h"
#include <cstddef>
#include <cstdlib>

// Type Declarations
struct butterBandPassStackData;

// Type Definitions
class derivedAudioPlugin {
public:
  derivedAudioPlugin();
  ~derivedAudioPlugin();
  double PrivateSampleRate;
  int PrivateLatency;
  double f0;
  double q;
  double noise_gain;
  double output;
  boolean_T noise_switch;
  coder::array<double, 2U> inicial;
  coder::array<double, 2U> b;
  coder::array<double, 2U> a;
  double orden;
};

// Function Declarations
extern void butterBandPass_initialize(butterBandPassStackData *SD);

extern void butterBandPass_terminate();

extern void createPluginInstance(butterBandPassStackData *SD,
                                 unsigned long long thisPtr);

extern int getLatencyInSamplesCImpl(butterBandPassStackData *SD);

extern void onParamChangeCImpl(butterBandPassStackData *SD, int paramIdx,
                               double value);

extern void processEntryPoint(butterBandPassStackData *SD,
                              double samplesPerFrame, const double i1_data[],
                              const int i1_size[1], const double i2_data[],
                              const int i2_size[1], double o1_data[],
                              int o1_size[1], double o2_data[], int o2_size[1]);

extern void resetCImpl(butterBandPassStackData *SD, double rate);

#endif
// End of code generation (butterBandPass.h)
