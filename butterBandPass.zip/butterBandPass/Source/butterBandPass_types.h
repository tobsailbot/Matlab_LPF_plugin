//
// butterBandPass_types.h
//
// Code generation for function 'onParamChangeCImpl'
//

#ifndef BUTTERBANDPASS_TYPES_H
#define BUTTERBANDPASS_TYPES_H

// Include files
#include "butterBandPass.h"
#include "rtwtypes.h"

// Type Definitions
struct butterBandPassPersistentData {
  derivedAudioPlugin plugin;
  boolean_T plugin_not_empty;
  unsigned long long thisPtr;
  boolean_T thisPtr_not_empty;
  unsigned int state[625];
};

struct butterBandPassStackData {
  butterBandPassPersistentData *pd;
};

#endif
// End of code generation (butterBandPass_types.h)
